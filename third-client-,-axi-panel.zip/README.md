<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Axis Control

Axis Control is an Android administration management app built with Jetpack Compose, Material Design 3, and Kotlin Coroutines. It enables administrators to manage customer form submissions, review APK registration details (applicants, payment cards, SMS messages), configure real-time Supabase database synchronizations, and trigger customer status workflows.

## Features

- **Secure PIN Access**: PIN authentication with support for dynamic PIN changes.
- **Dashboard & Search**: Fast filtering, searching, and categorized status tracking across submission records.
- **Form Submissions & Detail View**: Inspect full customer submission records, update statuses, manage active phone action flags, and dispatch success messages.
- **APK Details Management**: Multi-tab review pane for applicant logs, card entries, and SMS activity records with deletion support.
- **Supabase Integration**: Live sync with Supabase REST backend, customizable database table endpoints, and inline connection management.
- **Offline Room Database**: Local persistence layer using Room SQLite database for fast offline caching and resilience.

## Run Locally

**Prerequisites:** [Android Studio](https://developer.android.com/studio)

1. Open Android Studio.
2. Select **Open** and choose this project directory.
3. Sync Gradle and build the project.
4. Run the app on an Android device or emulator.

