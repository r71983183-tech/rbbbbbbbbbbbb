package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val AxisColorScheme = darkColorScheme(
    primary = PrimaryBurgundy,
    onPrimary = TextPrimary,
    primaryContainer = CanvasCardElevated,
    onPrimaryContainer = AccentAxisRedLight,
    secondary = AccentAxisRed,
    onSecondary = CanvasDark,
    secondaryContainer = CanvasInput,
    onSecondaryContainer = TextSecondary,
    tertiary = AccentEmerald,
    onTertiary = TextPrimary,
    background = CanvasDark,
    onBackground = TextPrimary,
    surface = CanvasCard,
    onSurface = TextPrimary,
    surfaceVariant = CanvasInput,
    onSurfaceVariant = TextSecondary,
    outline = CardBorder,
    outlineVariant = CardBorderHighlight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AxisColorScheme,
        typography = Typography(),
        content = content
    )
}
