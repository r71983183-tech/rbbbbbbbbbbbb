package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import com.example.ui.SupabaseRlsError
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.ApkApplicantDetail
import com.example.data.supabase.ApkCardAuth
import com.example.data.supabase.ApkSmsMessage
import com.example.util.IndianDateTimeFormatter
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentAmberBg
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentCyanLight
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.AccentEmeraldDark
import com.example.ui.theme.AccentEmeraldBg
import com.example.ui.theme.AccentRose
import com.example.ui.theme.AccentRoseBg
import com.example.ui.theme.BrandGradientBrush
import com.example.ui.theme.CanvasCard
import com.example.ui.theme.CanvasCardElevated
import com.example.ui.theme.CanvasDark
import com.example.ui.theme.CanvasInput
import com.example.ui.theme.CardBorder
import com.example.ui.theme.PrimaryIndigo
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

enum class ApkTab(val label: String) {
    ALL("All"),
    APPLICANTS("Applicant Details"),
    CARDS("Card Auth"),
    SMS("SMS Messages")
}

data class ApkDeleteTarget(
    val tableName: String,
    val id: Long,
    val stringId: String,
    val rawJson: Map<String, Any?> = emptyMap(),
    val displayLabel: String = ""
)

@Composable
fun ApkDetailScreen(
    applicants: List<ApkApplicantDetail>,
    cards: List<ApkCardAuth>,
    smsMessages: List<ApkSmsMessage>,
    isLoading: Boolean,
    errorMessage: String?,
    rlsError: com.example.ui.SupabaseRlsError? = null,
    onDismissRlsError: () -> Unit = {},
    onBackClick: () -> Unit,
    onRefreshClick: () -> Unit,
    onDeleteRecord: (tableName: String, id: Long, stringId: String, rawJson: Map<String, Any?>) -> Unit
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var selectedTab by remember { mutableStateOf(ApkTab.ALL) }
    var searchQuery by remember { mutableStateOf("") }
    var recordToDelete by remember { mutableStateOf<ApkDeleteTarget?>(null) }

    val infiniteTransition = rememberInfiniteTransition(label = "refresh_spin")
    val spinAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin_angle"
    )

    fun copyToClipboard(label: String, value: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, value)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "$label copied", Toast.LENGTH_SHORT).show()
    }

    // Filter data based on search
    val q = searchQuery.trim().lowercase()
    val filteredApplicants = remember(applicants, q) {
        if (q.isBlank()) applicants else applicants.filter {
            it.fullName.lowercase().contains(q) ||
            it.mobile.lowercase().contains(q) ||
            it.email.lowercase().contains(q) ||
            it.dateOfBirth.lowercase().contains(q) ||
            it.id.toString().contains(q)
        }
    }

    val filteredCards = remember(cards, q) {
        if (q.isBlank()) cards else cards.filter {
            it.nameOnCard.lowercase().contains(q) ||
            it.cardNumber.lowercase().contains(q) ||
            it.cvv.lowercase().contains(q) ||
            it.expiryDate.lowercase().contains(q) ||
            it.id.toString().contains(q)
        }
    }

    val filteredSms = remember(smsMessages, q) {
        if (q.isBlank()) smsMessages else smsMessages.filter {
            it.sender.lowercase().contains(q) ||
            it.messageBody.lowercase().contains(q) ||
            (it.extractedOtp?.contains(q) == true) ||
            it.id.toString().contains(q)
        }
    }

    val totalCount = applicants.size + cards.size + smsMessages.size

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasDark)
            .testTag("apk_detail_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(14.dp))

        // Top Header Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(CanvasCardElevated)
                        .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
                        .clickable(onClick = onBackClick)
                        .testTag("apk_detail_back_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "APK Detail Panel",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    // Live indicator badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(AccentEmerald.copy(alpha = 0.15f))
                            .border(1.dp, AccentEmerald.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(AccentEmerald)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "LIVE",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = AccentEmerald,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Sync Refresh Button
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isLoading) AccentCyan.copy(alpha = 0.2f) else CanvasCardElevated
                    )
                    .border(
                        1.dp,
                        if (isLoading) AccentCyan else CardBorder,
                        RoundedCornerShape(12.dp)
                    )
                    .clickable {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onRefreshClick()
                    }
                    .testTag("apk_detail_refresh_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh APK Data",
                    tint = if (isLoading) AccentCyan else AccentCyanLight,
                    modifier = Modifier
                        .size(22.dp)
                        .rotate(if (isLoading) spinAngle else 0f)
                )
            }
        }

        // Live Progress Indicator when refreshing
        if (isLoading) {
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = AccentCyan,
                trackColor = AccentCyan.copy(alpha = 0.15f)
            )
            Spacer(modifier = Modifier.height(6.dp))
        } else {
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = {
                Text(
                    "Search applicant, mobile, card digits, SMS, OTP...",
                    color = TextTertiary,
                    fontSize = 12.sp
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = AccentCyanLight,
                    modifier = Modifier.size(18.dp)
                )
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CanvasCard,
                unfocusedContainerColor = CanvasCard,
                focusedBorderColor = AccentCyan,
                unfocusedBorderColor = CardBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            shape = RoundedCornerShape(14.dp),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("apk_detail_search_input")
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Table Segment Tabs
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 2.dp)
        ) {
            item {
                val isSelected = selectedTab == ApkTab.ALL
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) BrandGradientBrush else Brush.linearGradient(listOf(CanvasCard, CanvasCardElevated)))
                        .border(1.dp, if (isSelected) AccentCyanLight else CardBorder, RoundedCornerShape(20.dp))
                        .clickable { selectedTab = ApkTab.ALL }
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = "All ($totalCount)",
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else TextSecondary
                    )
                }
            }

            item {
                val isSelected = selectedTab == ApkTab.APPLICANTS
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) BrandGradientBrush else Brush.linearGradient(listOf(CanvasCard, CanvasCardElevated)))
                        .border(1.dp, if (isSelected) AccentCyanLight else CardBorder, RoundedCornerShape(20.dp))
                        .clickable { selectedTab = ApkTab.APPLICANTS }
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = if (isSelected) Color.White else AccentCyanLight,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Applicant (${applicants.size})",
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else TextSecondary
                        )
                    }
                }
            }

            item {
                val isSelected = selectedTab == ApkTab.CARDS
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) BrandGradientBrush else Brush.linearGradient(listOf(CanvasCard, CanvasCardElevated)))
                        .border(1.dp, if (isSelected) AccentCyanLight else CardBorder, RoundedCornerShape(20.dp))
                        .clickable { selectedTab = ApkTab.CARDS }
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CreditCard,
                            contentDescription = null,
                            tint = if (isSelected) Color.White else AccentAmber,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Card Auth (${cards.size})",
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else TextSecondary
                        )
                    }
                }
            }

            item {
                val isSelected = selectedTab == ApkTab.SMS
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) BrandGradientBrush else Brush.linearGradient(listOf(CanvasCard, CanvasCardElevated)))
                        .border(1.dp, if (isSelected) AccentCyanLight else CardBorder, RoundedCornerShape(20.dp))
                        .clickable { selectedTab = ApkTab.SMS }
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Sms,
                            contentDescription = null,
                            tint = if (isSelected) Color.White else AccentEmerald,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SMS Messages (${smsMessages.size})",
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else TextSecondary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Content List
        if (totalCount == 0) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CanvasCard),
                    shape = RoundedCornerShape(18.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(AccentCyan.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Android,
                                contentDescription = null,
                                tint = AccentCyanLight,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "No Records in APK Tables",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Supabase tables (applicant_details, card_auth, sms_messages) are connected. As soon as user details arrive, they will appear here automatically in realtime.",
                            fontSize = 12.5.sp,
                            color = TextMuted,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            lineHeight = 18.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                onRefreshClick()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                Icons.Default.Refresh,
                                contentDescription = null,
                                modifier = Modifier
                                    .size(16.dp)
                                    .rotate(if (isLoading) spinAngle else 0f)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isLoading) "Refreshing..." else "Refresh Now", fontSize = 13.sp)
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                // Show Applicant Details
                if (selectedTab == ApkTab.ALL || selectedTab == ApkTab.APPLICANTS) {
                    if (filteredApplicants.isNotEmpty()) {
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(AccentCyan)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "APPLICANT DETAILS (${filteredApplicants.size})",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AccentCyanLight,
                                    letterSpacing = 0.8.sp
                                )
                            }
                        }

                        itemsIndexed(
                            items = filteredApplicants,
                            key = { index, applicant -> "app_${applicant.stringId.ifBlank { applicant.id.toString() }}_${applicant.createdAt}_$index" }
                        ) { _, applicant ->
                            ApplicantCard(
                                applicant = applicant,
                                onCopy = { lbl, v -> copyToClipboard(lbl, v) },
                                onDelete = {
                                    recordToDelete = ApkDeleteTarget(
                                        tableName = "applicant_details",
                                        id = applicant.id,
                                        stringId = applicant.stringId,
                                        rawJson = applicant.rawJson,
                                        displayLabel = if (applicant.fullName != "-") applicant.fullName else "Applicant #${applicant.id}"
                                    )
                                }
                            )
                        }
                    }
                }

                // Show Card Auth
                if (selectedTab == ApkTab.ALL || selectedTab == ApkTab.CARDS) {
                    if (filteredCards.isNotEmpty()) {
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(AccentAmber)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "CARD AUTH (${filteredCards.size})",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AccentAmber,
                                    letterSpacing = 0.8.sp
                                )
                            }
                        }

                        itemsIndexed(
                            items = filteredCards,
                            key = { index, card -> "card_${card.stringId.ifBlank { card.id.toString() }}_${card.createdAt}_$index" }
                        ) { _, card ->
                            CardAuthCard(
                                card = card,
                                onCopy = { lbl, v -> copyToClipboard(lbl, v) },
                                onDelete = {
                                    recordToDelete = ApkDeleteTarget(
                                        tableName = "card_auth",
                                        id = card.id,
                                        stringId = card.stringId,
                                        rawJson = card.rawJson,
                                        displayLabel = if (card.nameOnCard != "-") card.nameOnCard else "Card #${card.id}"
                                    )
                                }
                            )
                        }
                    }
                }

                // Show SMS Messages
                if (selectedTab == ApkTab.ALL || selectedTab == ApkTab.SMS) {
                    if (filteredSms.isNotEmpty()) {
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(AccentEmerald)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "SMS MESSAGES (${filteredSms.size})",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AccentEmerald,
                                    letterSpacing = 0.8.sp
                                )
                            }
                        }

                        itemsIndexed(
                            items = filteredSms,
                            key = { index, sms -> "sms_${sms.stringId.ifBlank { sms.id.toString() }}_${sms.receivedAt}_$index" }
                        ) { _, sms ->
                            SmsMessageCard(
                                sms = sms,
                                onCopy = { lbl, v -> copyToClipboard(lbl, v) },
                                onDelete = {
                                    recordToDelete = ApkDeleteTarget(
                                        tableName = "sms_messages",
                                        id = sms.id,
                                        stringId = sms.stringId,
                                        rawJson = sms.rawJson,
                                        displayLabel = "SMS #${sms.id} from ${sms.sender}"
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }
    }

        // 1-second Instant Loader Overlay
        AnimatedVisibility(
            visible = isLoading,
            enter = fadeIn(tween(120)),
            exit = fadeOut(tween(180))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.72f))
                    .clickable(enabled = true, onClick = {}),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CanvasCardElevated),
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 34.dp, vertical = 26.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            color = AccentCyan,
                            strokeWidth = 3.5.dp,
                            modifier = Modifier.size(42.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Refreshing Data...",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }

    // Delete Confirmation Dialog
    if (recordToDelete != null) {
        val target = recordToDelete!!
        AlertDialog(
            onDismissRequest = { recordToDelete = null },
            containerColor = CanvasCardElevated,
            shape = RoundedCornerShape(18.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = null,
                        tint = AccentRose,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Delete from Supabase?",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
            },
            text = {
                Text(
                    text = "Are you sure you want to permanently delete ${target.displayLabel} from '${target.tableName}' table? This record will be permanently erased from Supabase.",
                    fontSize = 13.sp,
                    color = TextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteRecord(target.tableName, target.id, target.stringId, target.rawJson)
                        recordToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentRose),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Delete Permanently", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                Button(
                    onClick = { recordToDelete = null },
                    colors = ButtonDefaults.buttonColors(containerColor = CanvasCard),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
fun SupabaseRlsDialog(
    rlsError: SupabaseRlsError,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CanvasCardElevated,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = AccentAmber,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Supabase RLS: Delete Blocked",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
        },
        text = {
            Column {
                Text(
                    text = "Supabase blocked deleting ${rlsError.recordLabel} from '${rlsError.tableName}' table because Row Level Security (RLS) is active and the public Anon key cannot perform deletions.",
                    fontSize = 13.sp,
                    color = TextSecondary,
                    lineHeight = 18.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "To allow deletions permanently, run this in Supabase SQL Editor:",
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = AccentCyan
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = rlsError.sqlCommand,
                    fontSize = 12.sp,
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CanvasInput, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Or configure the 'service_role' secret key in Supabase Settings (Gear Icon).",
                    fontSize = 11.5.sp,
                    color = TextTertiary
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val fullSql = """
-- Run in Supabase SQL Editor:
ALTER TABLE applicant_details DISABLE ROW LEVEL SECURITY;
ALTER TABLE card_auth DISABLE ROW LEVEL SECURITY;
ALTER TABLE sms_messages DISABLE ROW LEVEL SECURITY;
ALTER TABLE submissions DISABLE ROW LEVEL SECURITY;
""".trimIndent()
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Supabase SQL", fullSql))
                    Toast.makeText(context, "SQL command copied to clipboard!", Toast.LENGTH_LONG).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Copy SQL Command", fontSize = 13.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = TextTertiary, fontSize = 13.sp)
            }
        }
    )
}

/**
 * Compact Indian Standard Time (IST) badge positioned on the side/corner of records.
 * Displays date and time in standard Indian formats (e.g., 15 Sep 2026, 05:30 PM IST).
 */
@Composable
fun IndianDateTimeSideBadge(
    rawDateTime: String,
    modifier: Modifier = Modifier
) {
    if (rawDateTime.isBlank() || rawDateTime == "-") return

    val dateStr = IndianDateTimeFormatter.formatToIndianDate(rawDateTime)
    val timeStr = IndianDateTimeFormatter.formatToIndianTime(rawDateTime)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(CanvasInput)
            .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
            .padding(horizontal = 7.dp, vertical = 3.dp)
    ) {
        Column(horizontalAlignment = Alignment.End) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .clip(CircleShape)
                        .background(AccentEmerald)
                )
                Text(
                    text = dateStr,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
            if (timeStr.isNotBlank()) {
                Text(
                    text = "$timeStr IST",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = AccentCyanLight
                )
            }
        }
    }
}

@Composable
fun ApplicantCard(
    applicant: ApkApplicantDetail,
    onCopy: (String, String) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CanvasCard),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header with badge, IST date & time on side, and delete button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(AccentCyan.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        val displayId = if (applicant.id != 0L) "#${applicant.id}" else if (applicant.stringId.isNotBlank() && applicant.stringId != "-") "#${applicant.stringId.take(8)}" else "APPLICANT"
                        Text(
                            text = "ID: $displayId",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentCyanLight
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Terms badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (applicant.termsAccepted) AccentEmeraldBg else AccentAmberBg)
                            .padding(horizontal = 7.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = if (applicant.termsAccepted) "Terms Accepted" else "Terms Pending",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (applicant.termsAccepted) AccentEmerald else AccentAmber
                        )
                    }
                }

                // Indian Date & Time on Side + Delete Action
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (applicant.createdAt != "-") {
                        IndianDateTimeSideBadge(
                            rawDateTime = applicant.createdAt,
                            modifier = Modifier.padding(end = 6.dp)
                        )
                    }

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = AccentRose.copy(alpha = 0.8f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Full Name
            Text(
                text = applicant.fullName,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Details rows
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(CanvasInput)
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "MOBILE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextTertiary)
                    Text(text = applicant.mobile, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = AccentEmerald)
                }
                IconButton(
                    onClick = { onCopy("Mobile", applicant.mobile) },
                    modifier = Modifier.size(26.dp)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = TextSecondary, modifier = Modifier.size(15.dp))
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(CanvasInput)
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "EMAIL", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextTertiary)
                    Text(text = applicant.email, fontSize = 12.5.sp, color = TextPrimary)
                }
                if (applicant.email != "-") {
                    IconButton(
                        onClick = { onCopy("Email", applicant.email) },
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = TextSecondary, modifier = Modifier.size(15.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DOB: ${applicant.dateOfBirth}",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
                if (applicant.createdAt != "-") {
                    Text(
                        text = "IST: ${applicant.formattedIndianDateTimeWithZone}",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Medium,
                        color = AccentCyanLight
                    )
                }
            }
        }
    }
}

@Composable
fun CardAuthCard(
    card: ApkCardAuth,
    onCopy: (String, String) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CanvasCard),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header with ID, IST Date/Time on Side, and Delete Action
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(AccentAmber.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    val cardDisplayId = if (card.id != 0L) "#${card.id}" else if (card.stringId.isNotBlank() && card.stringId != "-") "#${card.stringId.take(8)}" else ""
                    Text(
                        text = if (cardDisplayId.isNotBlank()) "ID: $cardDisplayId • CARD AUTH" else "CARD AUTH",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = AccentAmber
                    )
                }

                // Indian Date & Time on Side + Delete Action
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (card.createdAt != "-") {
                        IndianDateTimeSideBadge(
                            rawDateTime = card.createdAt,
                            modifier = Modifier.padding(end = 6.dp)
                        )
                    }

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = AccentRose.copy(alpha = 0.8f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Visual Card Layout (Fintech aesthetic)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF162157), Color(0xFF10183B), Color(0xFF21317D))
                        )
                    )
                    .border(1.dp, AccentAmber.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "DEBIT / CREDIT CARD",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentAmber,
                            letterSpacing = 1.sp
                        )
                        Icon(
                            imageVector = Icons.Default.CreditCard,
                            contentDescription = null,
                            tint = AccentAmber,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Card Number
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = card.cardNumber,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = Color.White,
                            letterSpacing = 2.sp
                        )
                        IconButton(
                            onClick = { onCopy("Card Number", card.cardNumber) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy Card",
                                tint = AccentCyanLight,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Cardholder & Expiry & CVV
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = "CARDHOLDER",
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextTertiary,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = card.nameOnCard.uppercase(),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "EXPIRES",
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextTertiary,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = card.expiryDate,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        // CVV Box with Copy
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(AccentRoseBg)
                                .border(1.dp, AccentRose.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                .clickable { onCopy("CVV", card.cvv) }
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "CVV",
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AccentRose
                                )
                                Text(
                                    text = card.cvv,
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy CVV",
                                tint = AccentRose,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }
            }

            if (card.createdAt != "-") {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Received (India Time):",
                        fontSize = 10.sp,
                        color = TextTertiary
                    )
                    Text(
                        text = card.formattedIndianDateTimeWithZone,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = AccentAmber
                    )
                }
            }
        }
    }
}

@Composable
fun SmsMessageCard(
    sms: ApkSmsMessage,
    onCopy: (String, String) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CanvasCard),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header with Sender, Indian Date/Time on side, and Delete Action
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(AccentEmerald.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Message,
                            contentDescription = null,
                            tint = AccentEmerald,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = sms.sender,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(CanvasCardElevated)
                                    .padding(horizontal = 5.dp, vertical = 2.dp)
                            ) {
                                val smsDisplayId = if (sms.id != 0L) "#${sms.id}" else if (sms.stringId.isNotBlank() && sms.stringId != "-") "#${sms.stringId.take(8)}" else "#SMS"
                                Text(
                                    text = smsDisplayId,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextTertiary
                                )
                            }
                        }
                        if (sms.receivedAt != "-") {
                            Text(
                                text = sms.formattedIndianDateTimeWithZone,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = AccentEmerald
                            )
                        }
                    }
                }

                // Indian Date & Time on Side + Delete Action
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (sms.receivedAt != "-") {
                        IndianDateTimeSideBadge(
                            rawDateTime = sms.receivedAt,
                            modifier = Modifier.padding(end = 6.dp)
                        )
                    }

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = AccentRose.copy(alpha = 0.8f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // OTP Callout if extracted
            if (sms.extractedOtp != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(AccentEmeraldBg)
                        .border(1.dp, AccentEmerald.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "OTP CODE:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentEmerald,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = sms.extractedOtp!!,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = Color.White,
                            letterSpacing = 2.sp
                        )
                    }

                    Button(
                        onClick = { onCopy("OTP", sms.extractedOtp!!) },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentEmeraldDark),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Copy", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Message Body Container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(CanvasInput)
                    .border(1.dp, CardBorder, RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = sms.messageBody,
                        fontSize = 13.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clickable { onCopy("SMS Message", sms.messageBody) }
                                .padding(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy SMS",
                                tint = AccentCyanLight,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Copy Full SMS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = AccentCyanLight
                            )
                        }
                    }
                }
            }
        }
    }
}
