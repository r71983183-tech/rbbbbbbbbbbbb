package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Axis Bank Theme Palette (Burgundy / Maroon & Red)
val CanvasDark = Color(0xFF0F070A)
val CanvasDarkSubtle = Color(0xFF170C11)
val CanvasCard = Color(0xFF221119)
val CanvasCardElevated = Color(0xFF2E1722)
val CanvasInput = Color(0xFF190D13)
val CardBorder = Color(0xFF421D2F)
val CardBorderHighlight = Color(0xFF6B2F4C)
val CardBorderGlow = Color(0xFF8B0032)

// Brand & Accent Colors - Axis Burgundy / Red
val PrimaryBurgundy = Color(0xFF8B0032)
val PrimaryBurgundyDark = Color(0xFF5C0022)
val PrimaryBurgundyLight = Color(0xFFA81C4A)
val AccentAxisRed = Color(0xFFED1B24)
val AccentAxisRedLight = Color(0xFFFF6B73)
val AccentEmerald = Color(0xFF10B981)
val AccentEmeraldDark = Color(0xFF059669)
val AccentEmeraldBg = Color(0xFF064E3B)
val AccentAmber = Color(0xFFF59E0B)
val AccentAmberDark = Color(0xFFD97706)
val AccentAmberBg = Color(0xFF451A03)
val AccentRose = Color(0xFFF43F5E)
val AccentRoseDark = Color(0xFFE11D48)
val AccentRoseBg = Color(0xFF4C0519)
val AccentPurple = Color(0xFF8B0032)

// Compatibility aliases for Axis theme
val PrimaryIndigo = PrimaryBurgundy
val PrimaryIndigoDark = PrimaryBurgundyDark
val PrimaryIndigoLight = PrimaryBurgundyLight
val AccentCyan = AccentAxisRed
val AccentCyanLight = AccentAxisRedLight

// Typography & Neutrals
val TextPrimary = Color(0xFFFFF5F7)
val TextSecondary = Color(0xFFE2C4CE)
val TextMuted = Color(0xFFA37A8C)
val TextTertiary = Color(0xFF73505F)

// Glassmorphism Accents
val GlassWhite08 = Color(0x14FFFFFF)
val GlassWhite12 = Color(0x1FFFFFFF)
val GlassWhite04 = Color(0x0AFFFFFF)

// Legacy alias compatibility for seamless references
val DarkTealBackground = CanvasDark
val DarkTealCard = CanvasCard
val DarkTealInput = CanvasInput
val DarkTealBorder = CardBorder
val AccentOrange = AccentAmber
val AccentOrangeDark = AccentAmberDark
val AccentBlueIcon = PrimaryBurgundy
val TextWhite = TextPrimary
val TextTealLight = AccentAxisRedLight
val StatusGreen = AccentEmerald
val StatusPending = AccentAmber
val StatusResolved = AccentAxisRed

// Gradient Brushes
val BrandGradientBrush = Brush.horizontalGradient(
    listOf(PrimaryBurgundy, AccentAxisRed)
)

val CardGlowBrush = Brush.linearGradient(
    listOf(Color(0xFF8B0032), Color(0xFF190D13))
)

val SuccessGradientBrush = Brush.horizontalGradient(
    listOf(Color(0xFF059669), Color(0xFF10B981))
)

val AmberGradientBrush = Brush.horizontalGradient(
    listOf(Color(0xFFD97706), Color(0xFFF59E0B))
)
