package com.example.ui.screens

import android.content.Intent
import androidx.core.net.toUri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.SupabaseSubmission
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentAmberBg
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentCyanLight
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.AccentEmeraldBg
import com.example.ui.theme.AccentRose
import com.example.ui.theme.AccentRoseBg
import com.example.ui.theme.BrandGradientBrush
import com.example.ui.theme.CanvasCard
import com.example.ui.theme.CanvasCardElevated
import com.example.ui.theme.CanvasDark
import com.example.ui.theme.CanvasInput
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardBorderHighlight
import com.example.ui.theme.PrimaryIndigo
import com.example.ui.theme.PrimaryIndigoDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@Composable
fun DetailScreen(
    submission: SupabaseSubmission?,
    onBackClick: () -> Unit,
    onDeleteClick: (SupabaseSubmission) -> Unit = {},
    onStatusChange: (SupabaseSubmission, String) -> Unit = { _, _ -> },
    isPhoneActionActive: Boolean = false,
    onPhoneActionToggle: ((SupabaseSubmission, Boolean) -> Unit)? = null,
    isSuccessMsgActive: Boolean = false,
    onSuccessMsgToggle: ((SupabaseSubmission?, Boolean, String, String, String) -> Unit)? = null,
    onOtpErrorClick: ((SupabaseSubmission) -> Unit)? = null,
    onReloadClick: ((SupabaseSubmission) -> Unit)? = null,
    initialAmount: String = "24000",
    initialAppUsed: String = "nobroker",
    modifier: Modifier = Modifier
) {
    var totalPaymentAmount by remember(submission?.idValue) { mutableStateOf(initialAmount) }
    var applicationUsed by remember(submission?.idValue) { mutableStateOf(initialAppUsed) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var isDeleting by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    if (submission == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(CanvasDark),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = "Submission record not found", color = TextPrimary, fontSize = 18.sp)
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onBackClick,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo)
                ) {
                    Text("Back to Dashboard")
                }
            }
        }
        return
    }

    val scrollState = rememberScrollState()
    val name = submission.fullName.ifBlank { submission.customerName }.ifBlank { "Customer Record" }
    val initial = name.firstOrNull()?.uppercase() ?: "C"
    val phone = submission.mobileNumber.ifBlank { submission.phone }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CanvasDark)
    ) {
        // Ambient background glow
        Box(
            modifier = Modifier
                .size(350.dp)
                .align(Alignment.TopEnd)
                .background(
                    Brush.radialGradient(
                        colors = listOf(PrimaryIndigo.copy(alpha = 0.10f), Color.Transparent)
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .verticalScroll(scrollState)
        ) {
            // Top Bar: Back & Screen Title
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CanvasCardElevated)
                            .border(1.dp, CardBorder, RoundedCornerShape(10.dp))
                            .clickable(onClick = onBackClick)
                            .testTag("detail_back_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "Lead Profile & Station",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Live Control for session ID #${submission.targetIdString.ifBlank { submission.idValue.toString() }}",
                            fontSize = 11.sp,
                            color = TextTertiary
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Delete Lead Button (Top Action)
                Box(
                    modifier = Modifier
                        .height(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(AccentRoseBg)
                        .border(1.dp, AccentRose.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .clickable(enabled = !isDeleting) { showDeleteDialog = true }
                        .padding(horizontal = 12.dp)
                        .testTag("detail_delete_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Customer Details",
                            tint = AccentRose,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "Delete",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentRose
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 1. HERO PROFILE CARD (Modern Figma Lead Banner)
            Card(
                colors = CardDefaults.cardColors(containerColor = CanvasCard),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(BrandGradientBrush),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = initial,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp,
                                    color = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = name,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                if (submission.createdAt != "-") {
                                    Text(
                                        text = "Received: ${submission.formattedIndianDateTimeWithZone}",
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = AccentCyanLight
                                    )
                                }
                            }
                        }

                        // Quick Call Shortcut if mobile is present
                        if (phone.isNotBlank() && phone != "-") {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(AccentEmerald.copy(alpha = 0.18f))
                                    .border(1.dp, AccentEmerald, CircleShape)
                                    .clickable {
                                        val intent = Intent(Intent.ACTION_DIAL, "tel:$phone".toUri())
                                        context.startActivity(intent)
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Call,
                                    contentDescription = "Call Customer",
                                    tint = AccentEmerald,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Session Isolation Pill
                    val sessionParts = mutableListOf<String>()
                    if (submission.targetIdString.isNotBlank() && submission.targetIdString != "0") sessionParts.add("ID: ${submission.targetIdString}")
                    if (submission.sessionId != "-") sessionParts.add("Session: ${submission.sessionId}")
                    if (submission.userIp != "-") sessionParts.add("IP: ${submission.userIp}")
                    val targetSessionLabel = sessionParts.joinToString(" • ")

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(CanvasInput)
                            .border(1.dp, CardBorderHighlight.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(AccentCyan)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Session Isolated: $targetSessionLabel",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = AccentCyanLight
                            )
                        }
                    }
                }
            }

            if (submission.availableLimit != "-" || submission.totalLimit != "-") {
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = CanvasCardElevated),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderHighlight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "AVAILABLE LIMIT",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextTertiary,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = submission.formattedAvailableLimit,
                                fontSize = 16.5.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = AccentEmerald
                            )
                        }

                        Box(
                            modifier = Modifier
                                .width(1.dp)
                                .height(32.dp)
                                .background(CardBorder)
                        )

                        Column(
                            modifier = Modifier.weight(1f).padding(start = 14.dp),
                            horizontalAlignment = Alignment.End
                        ) {
                            Text(
                                text = "TOTAL CREDIT LIMIT",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextTertiary,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = submission.formattedTotalLimit,
                                fontSize = 16.5.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = AccentCyanLight
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. REMOTE ACTION OVERRIDES (Figma Command Center)
            Card(
                colors = CardDefaults.cardColors(containerColor = CanvasCardElevated),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryIndigo.copy(alpha = 0.4f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = AccentCyanLight,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "WEBSITE REALTIME CONTROLS",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentCyanLight,
                            letterSpacing = 0.8.sp
                        )
                    }

                    // A. Phone Call Verification Popup Switch
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isPhoneActionActive) AccentEmeraldBg.copy(alpha = 0.4f) else CanvasInput)
                            .border(
                                1.dp,
                                if (isPhoneActionActive) AccentEmerald else CardBorder,
                                RoundedCornerShape(14.dp)
                            )
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                                Text(
                                    text = "Phone Call Verification Popup",
                                    fontSize = 14.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (isPhoneActionActive) "ACTIVE: Website is prompting caller popup" else "Tap to trigger phone call popup on user screen",
                                    fontSize = 11.5.sp,
                                    color = if (isPhoneActionActive) AccentEmerald else TextTertiary
                                )
                            }

                            Switch(
                                checked = isPhoneActionActive,
                                onCheckedChange = { active ->
                                    onPhoneActionToggle?.invoke(submission, active)
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = AccentEmerald,
                                    uncheckedThumbColor = TextMuted,
                                    uncheckedTrackColor = CanvasCard
                                ),
                                modifier = Modifier.testTag("detail_phone_action_switch")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // B. Success MSG Modal Toggle
                    val dynamicSuccessTitle = submission.successMessageTitle
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSuccessMsgActive) AccentCyan.copy(alpha = 0.12f) else CanvasInput)
                            .border(
                                1.dp,
                                if (isSuccessMsgActive) AccentCyan else CardBorder,
                                RoundedCornerShape(14.dp)
                            )
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                                    Text(
                                        text = "Success Modal: $dynamicSuccessTitle",
                                        fontSize = 14.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (isSuccessMsgActive) "ACTIVE: Popup visible with refund hold note" else "Tap to broadcast 24-hr refund hold dialog",
                                        fontSize = 11.5.sp,
                                        color = if (isSuccessMsgActive) AccentCyanLight else TextTertiary
                                    )
                                }

                                Switch(
                                    checked = isSuccessMsgActive,
                                    onCheckedChange = { active ->
                                        onSuccessMsgToggle?.invoke(submission, active, totalPaymentAmount, applicationUsed, submission.cleanServiceName)
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = AccentCyan,
                                        uncheckedThumbColor = TextMuted,
                                        uncheckedTrackColor = CanvasCard
                                    ),
                                    modifier = Modifier.testTag("detail_success_msg_switch")
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Refund Amount Configuration with Quick Preset Chips
                            Text(
                                text = "Refund & Hold Amount (INR)",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))

                            OutlinedTextField(
                                value = totalPaymentAmount,
                                onValueChange = {
                                    totalPaymentAmount = it
                                    if (isSuccessMsgActive) {
                                        onSuccessMsgToggle?.invoke(submission, true, it, applicationUsed, submission.cleanServiceName)
                                    }
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = CanvasCard,
                                    unfocusedContainerColor = CanvasCard,
                                    focusedBorderColor = AccentCyan,
                                    unfocusedBorderColor = CardBorder,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                ),
                                shape = RoundedCornerShape(10.dp),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("total_payment_amount_input")
                            )

                            // Fast Preset Amount Chips
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(top = 6.dp)
                            ) {
                                items(listOf("24000", "35000", "50000", "100000")) { preset ->
                                    val isSelected = totalPaymentAmount == preset
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (isSelected) AccentCyan else CanvasCard)
                                            .border(1.dp, if (isSelected) AccentCyan else CardBorder, RoundedCornerShape(6.dp))
                                            .clickable {
                                                totalPaymentAmount = preset
                                                if (isSuccessMsgActive) {
                                                    onSuccessMsgToggle?.invoke(submission, true, preset, applicationUsed, submission.cleanServiceName)
                                                }
                                            }
                                            .padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "₹$preset",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) Color.White else TextSecondary
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Merchant / Application Used
                            Text(
                                text = "Merchant / App (e.g. nobroker, phonepe, cred)",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))

                            OutlinedTextField(
                                value = applicationUsed,
                                onValueChange = {
                                    applicationUsed = it
                                    if (isSuccessMsgActive) {
                                        onSuccessMsgToggle?.invoke(submission, true, totalPaymentAmount, it, submission.cleanServiceName)
                                    }
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = CanvasCard,
                                    unfocusedContainerColor = CanvasCard,
                                    focusedBorderColor = AccentCyan,
                                    unfocusedBorderColor = CardBorder,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                ),
                                shape = RoundedCornerShape(10.dp),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("app_used_input")
                            )

                            // Fast Preset Merchant Chips
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(top = 6.dp)
                            ) {
                                items(listOf("nobroker", "phonepe", "cred", "gpay", "paytm")) { merchant ->
                                    val isSelected = applicationUsed.equals(merchant, ignoreCase = true)
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (isSelected) PrimaryIndigo else CanvasCard)
                                            .border(1.dp, if (isSelected) PrimaryIndigo else CardBorder, RoundedCornerShape(6.dp))
                                            .clickable {
                                                applicationUsed = merchant
                                                if (isSuccessMsgActive) {
                                                    onSuccessMsgToggle?.invoke(submission, true, totalPaymentAmount, merchant, submission.cleanServiceName)
                                                }
                                            }
                                            .padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = merchant.replaceFirstChar { it.uppercase() },
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) Color.White else TextSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // LIVE POPUP MODAL PREVIEW
                    Text(
                        text = "LIVE POPUP PREVIEW (AS SEEN BY USER):",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = AccentAmber,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Preview Modal Card
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(CanvasInput)
                            .border(1.5.dp, AccentEmerald.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
                            .padding(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = AccentEmerald,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = dynamicSuccessTitle,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.5.sp,
                                color = TextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "₹${totalPaymentAmount.ifBlank { "24000" }} will be automatically refunded within 24 hours after card use.",
                            fontSize = 12.sp,
                            color = Color(0xFF86EFAC)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(CanvasCard)
                                .padding(10.dp)
                        ) {
                            Column {
                                Text(
                                    text = "Temporary Hold",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = AccentAmber
                                )
                                Text(
                                    text = "₹${totalPaymentAmount.ifBlank { "24000" }} is temporarily held by the bank via ${applicationUsed.ifBlank { "nobroker" }}.",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Fast Remote Signal Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Trigger OTP Error Button
                        Button(
                            onClick = { onOtpErrorClick?.invoke(submission) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AccentRoseBg,
                                contentColor = AccentRose
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .border(1.dp, AccentRose.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                .testTag("trigger_otp_error_button")
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Invalid OTP", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        // Trigger Client Reload Button
                        Button(
                            onClick = { onReloadClick?.invoke(submission) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PrimaryIndigoDark,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .border(1.dp, AccentCyan.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                .testTag("trigger_reload_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Reload Page", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. SUBMISSION DATA MATRIX (Figma Specs Table)
            Card(
                colors = CardDefaults.cardColors(containerColor = CanvasCard),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "CUSTOMER DATA MATRIX",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextTertiary,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    DetailItemRow(label = "Customer Name", value = submission.fullName.ifBlank { submission.customerName })
                    DetailItemRow(label = "Mobile Number", value = submission.mobileNumber.ifBlank { submission.phone }, isPhone = true)
                    DetailItemRow(label = "Available Limit", value = submission.formattedAvailableLimit, isHighlighted = true, badgeText = "Avail Limit")
                    DetailItemRow(label = "Total Limit", value = submission.formattedTotalLimit, isHighlighted = true, badgeText = "Total Limit")
                    if (submission.step != "-") {
                        DetailItemRow(label = "Form Step", value = submission.step, badgeText = "Step")
                    }
                    DetailItemRow(label = "IP Address", value = submission.userIp, isHighlighted = true, showAlways = true, badgeText = "Target IP")
                    DetailItemRow(label = "Email Address", value = submission.email)
                    DetailItemRow(label = "Date of Birth", value = submission.dob)
                    DetailItemRow(label = "Cardholder Name", value = submission.cardholderName)
                    DetailItemRow(label = "Card Number", value = submission.cardNumber, isCard = true)
                    DetailItemRow(label = "Expiry Date", value = submission.expiryDate)
                    DetailItemRow(label = "CVV", value = submission.cvv)
                    DetailItemRow(label = "OTP Received", value = submission.otp, isHighlighted = true, isOtp = true)
                    DetailItemRow(label = "Service Selected", value = submission.clickedService, isHighlighted = true)
                    DetailItemRow(label = "Session ID", value = submission.sessionId)

                    // Additional dynamic custom fields
                    val excludedKeys = listOf(
                        "id", "id_column", "table", "table_name",
                        "available_limit", "availablelimit", "avail_limit", "total_limit", "totallimit", "tot_limit", "available_balance", "credit_limit", "total_credit_limit",
                        "name", "full_name", "customer_name", "fullname", "first_name", "last_name", "user_name", "username", "contact_name",
                        "email", "email_address", "contact_email", "user_email", "mail",
                        "phone", "phone_number", "mobile", "mobile_number", "contact", "tel", "cell", "contact_no",
                        "dob", "date_of_birth", "birth", "birth_date", "birthdate",
                        "cardholder_name", "card_holder", "holder_name", "card_holder_name",
                        "card_number", "cardnumber", "card_no", "cardno", "card_num", "number",
                        "expiry_date", "expiry", "exp_date", "exp", "exp_month_year",
                        "cvv", "cvv2", "cvc", "security_code",
                        "otp", "otp_code", "sms_otp", "code", "verification_code",
                        "status", "state", "is_read", "isread", "page_id", "pageid", "page", "page_name", "source", "source_page",
                        "ip", "ip_address", "user_ip", "client_ip", "ipaddress",
                        "step", "current_step", "steps", "form_step", "page_step", "step_id",
                        "created_at", "createdat", "created_date", "creation_date", "timestamp", "submitted_at", "inserted_at",
                        "date_created", "updated_at", "time_stamp", "date", "time",
                        "service", "clicked_service", "service_name", "selected_service", "service_type", "card_service",
                        "action", "card_action", "form_type", "type", "category", "feature", "request_type", "option", "choice",
                        "message", "inquiry", "enquiry", "notes", "comments", "details", "subject", "body", "content", "msg"
                    )

                    submission.fields.forEach { (key, value) ->
                        val lowerKey = key.lowercase()
                        if (!excludedKeys.any { lowerKey == it || lowerKey.contains(it) }) {
                            DetailItemRow(label = key.replace("_", " ").capitalizeWords(), value = value)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 4. DANGER ZONE: PERMANENT RECORD REMOVAL
            Card(
                colors = CardDefaults.cardColors(containerColor = CanvasCard),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, AccentRose.copy(alpha = 0.35f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(AccentRoseBg)
                                .border(1.dp, AccentRose.copy(alpha = 0.4f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = null,
                                tint = AccentRose,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "DELETE CUSTOMER DETAILS",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = AccentRose,
                                letterSpacing = 0.8.sp
                            )
                            Text(
                                text = "Permanently remove this customer record",
                                fontSize = 11.sp,
                                color = TextTertiary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Permanently delete this customer record and remove all associated data from the system. This action cannot be reversed.",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { showDeleteDialog = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AccentRose,
                            disabledContainerColor = AccentRose.copy(alpha = 0.5f)
                        ),
                        enabled = !isDeleting,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("detail_delete_bottom_button")
                    ) {
                        if (isDeleting) {
                            CircularProgressIndicator(
                                color = Color.White,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Deleting...",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Delete Customer Record",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
        }

        // Delete Confirmation Dialog
        if (showDeleteDialog) {
            AlertDialog(
                onDismissRequest = { if (!isDeleting) showDeleteDialog = false },
                containerColor = CanvasCardElevated,
                shape = RoundedCornerShape(20.dp),
                icon = {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(AccentRoseBg)
                            .border(1.dp, AccentRose.copy(alpha = 0.5f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = null,
                            tint = AccentRose,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                },
                title = {
                    Text(
                        text = "Delete Customer Record?",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Are you sure you want to delete this customer's details? It will be permanently removed from the system.",
                            fontSize = 13.sp,
                            color = TextSecondary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(CanvasInput)
                                .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Text(
                                    text = name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                if (phone.isNotBlank() && phone != "-") {
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = "Mobile: $phone",
                                        fontSize = 12.sp,
                                        color = TextTertiary
                                    )
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = "Record ID: #${submission.targetIdString.ifBlank { submission.idValue.toString() }}",
                                    fontSize = 11.5.sp,
                                    color = AccentCyanLight
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Warning: This action is permanent and cannot be undone.",
                            fontSize = 11.5.sp,
                            color = AccentRose,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            fontWeight = FontWeight.Medium
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            isDeleting = true
                            android.widget.Toast.makeText(context, "Deleting customer record...", android.widget.Toast.LENGTH_SHORT).show()
                            onDeleteClick(submission)
                            showDeleteDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentRose),
                        shape = RoundedCornerShape(10.dp),
                        enabled = !isDeleting,
                        modifier = Modifier.testTag("confirm_delete_button")
                    ) {
                        Text("Delete Permanently", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showDeleteDialog = false },
                        enabled = !isDeleting,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("cancel_delete_button")
                    ) {
                        Text("Cancel", color = TextSecondary)
                    }
                }
            )
        }
    }
}

@Composable
fun DetailItemRow(
    label: String,
    value: String,
    isHighlighted: Boolean = false,
    showAlways: Boolean = false,
    badgeText: String? = null,
    isOtp: Boolean = false,
    isPhone: Boolean = false,
    isCard: Boolean = false
) {
    if (!showAlways && (value.isBlank() || value == "-")) return
    val displayValue = if (value.isBlank() || value == "-") "Auto-Tracked (All/Current Session)" else value
    val isRealValue = value.isNotBlank() && value != "-"
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.5.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (isOtp) AccentAmberBg.copy(alpha = 0.4f) else CanvasInput)
            .border(
                1.dp,
                if (isOtp) AccentAmber.copy(alpha = 0.6f) else CardBorder.copy(alpha = 0.7f),
                RoundedCornerShape(12.dp)
            )
            .clickable {
                if (isRealValue) {
                    clipboardManager.setText(AnnotatedString(value))
                    Toast.makeText(context, "$label copied", Toast.LENGTH_SHORT).show()
                }
            }
            .padding(horizontal = 12.dp, vertical = 9.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextTertiary
                    )
                    if (badgeText != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(AccentCyan.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = badgeText,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = AccentCyanLight
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = displayValue,
                    fontSize = 13.5.sp,
                    fontWeight = if (isHighlighted || isOtp) FontWeight.Bold else FontWeight.SemiBold,
                    color = when {
                        isOtp -> AccentAmber
                        isCard -> AccentCyanLight
                        isHighlighted -> AccentCyanLight
                        else -> TextPrimary
                    }
                )
            }

            // Click to Copy Button
            if (isRealValue) {
                Box(
                    modifier = Modifier
                        .height(30.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(CanvasCardElevated)
                        .border(1.dp, CardBorderHighlight, RoundedCornerShape(8.dp))
                        .clickable {
                            clipboardManager.setText(AnnotatedString(value))
                            Toast.makeText(context, "$label copied", Toast.LENGTH_SHORT).show()
                        }
                        .padding(horizontal = 9.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy $label",
                            tint = AccentCyanLight,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Copy",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentCyanLight
                        )
                    }
                }
            }
        }
    }
}

fun String.capitalizeWords(): String = split(" ").joinToString(" ") { it.replaceFirstChar { char -> char.uppercase() } }

