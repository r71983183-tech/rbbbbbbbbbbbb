package com.example.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object IndianDateTimeFormatter {
    private val IST_TIMEZONE = TimeZone.getTimeZone("Asia/Kolkata")

    private val inputFormats = listOf(
        "yyyy-MM-dd'T'HH:mm:ss.SSSSSSXXX",
        "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
        "yyyy-MM-dd'T'HH:mm:ssXXX",
        "yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'",
        "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
        "yyyy-MM-dd'T'HH:mm:ss'Z'",
        "yyyy-MM-dd'T'HH:mm:ss",
        "yyyy-MM-dd HH:mm:ss",
        "yyyy-MM-dd"
    )

    fun parseDate(raw: String?): Date? {
        if (raw.isNullOrBlank() || raw == "-") return null
        
        // Check if raw is a numeric timestamp (milliseconds or seconds)
        raw.toLongOrNull()?.let { num ->
            return if (num > 10_000_000_000L) Date(num) else Date(num * 1000L)
        }

        for (pattern in inputFormats) {
            try {
                val sdf = SimpleDateFormat(pattern, Locale.ENGLISH)
                if (pattern.contains("Z") || pattern.contains("XXX")) {
                    sdf.timeZone = TimeZone.getTimeZone("UTC")
                }
                sdf.isLenient = true
                val date = sdf.parse(raw)
                if (date != null) return date
            } catch (_: Exception) {
            }
        }
        return null
    }

    fun formatToIndianDate(raw: String?): String {
        val date = parseDate(raw) ?: return raw ?: "-"
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
        sdf.timeZone = IST_TIMEZONE
        return sdf.format(date)
    }

    fun formatToIndianTime(raw: String?): String {
        val date = parseDate(raw) ?: return raw ?: "-"
        val sdf = SimpleDateFormat("hh:mm a", Locale.ENGLISH)
        sdf.timeZone = IST_TIMEZONE
        return sdf.format(date)
    }

    fun formatToIndianDateTime(raw: String?): String {
        val date = parseDate(raw) ?: return raw ?: "-"
        val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH)
        sdf.timeZone = IST_TIMEZONE
        return sdf.format(date)
    }

    fun formatToIndianDateTimeWithZone(raw: String?): String {
        val dt = formatToIndianDateTime(raw)
        return if (dt.isNotBlank() && dt != "-") "$dt IST" else dt
    }

    fun formatToIndianDateSlash(raw: String?): String {
        val date = parseDate(raw) ?: return raw ?: "-"
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH)
        sdf.timeZone = IST_TIMEZONE
        return sdf.format(date)
    }

    fun formatRelativeOrDate(raw: String?): String {
        val date = parseDate(raw) ?: return raw ?: "-"
        val now = System.currentTimeMillis()
        val diff = now - date.time
        val seconds = diff / 1000
        val minutes = seconds / 60
        val hours = minutes / 60
        val days = hours / 24

        return when {
            days == 0L && hours < 24 -> {
                if (hours > 0) "${hours}h ago"
                else if (minutes > 0) "${minutes}m ago"
                else "Just now"
            }
            days == 1L -> "Yesterday"
            days in 2..6 -> "${days}d ago"
            else -> formatToIndianDate(raw)
        }
    }
}
