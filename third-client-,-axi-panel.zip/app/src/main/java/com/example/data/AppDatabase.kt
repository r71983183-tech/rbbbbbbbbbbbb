package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [FormEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun formDao(): FormDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "form_admin_database"
                )
                .addCallback(DatabaseCallback())
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateDatabase(database.formDao())
                    }
                }
            }

            suspend fun populateDatabase(formDao: FormDao) {
                val initialForms = listOf(
                    FormEntity(
                        id = 1,
                        customerName = "Himanshu Kumar",
                        email = "himanshukumar@gmail.com",
                        dob = "12/03/1990",
                        phone = "7463069093",
                        requestType = "Request Credit Limit Increase",
                        accountRef = "6011 2049 **** 3391",
                        securityCode = "109",
                        expiryDate = "04/30",
                        timestamp = "2026-07-23 18:57:39",
                        status = "Pending",
                        isOnline = true,
                        notes = "Customer requested limit expansion to 2,50,000 INR."
                    ),
                    FormEntity(
                        id = 2,
                        customerName = "Sharjil bismil",
                        email = "sharjil.bismil@gmail.com",
                        dob = "05/11/1994",
                        phone = "7301971707",
                        requestType = "Deactivate Card Protection",
                        accountRef = "4532 8812 **** 9012",
                        securityCode = "412",
                        expiryDate = "08/28",
                        timestamp = "2026-07-24 12:08:17",
                        status = "Pending",
                        isOnline = true,
                        notes = "Opting out of auto-renew protection plan."
                    ),
                    FormEntity(
                        id = 3,
                        customerName = "Ritik kumar",
                        email = "ritik.kumar@gmail.com",
                        dob = "19/08/1998",
                        phone = "7281802544",
                        requestType = "Deactivate Card Protection",
                        accountRef = "5120 4400 **** 7122",
                        securityCode = "883",
                        expiryDate = "11/29",
                        timestamp = "2026-07-24 13:22:33",
                        status = "Pending",
                        isOnline = true,
                        notes = "Customer confirmed via app portal."
                    ),
                    FormEntity(
                        id = 4,
                        customerName = "Anjali Sharma",
                        email = "anjali.sharma@gmail.com",
                        dob = "22/01/1995",
                        phone = "9823011245",
                        requestType = "Address Update Form",
                        accountRef = "3782 8224 **** 1190",
                        securityCode = "204",
                        expiryDate = "02/27",
                        timestamp = "2026-07-24 15:40:10",
                        status = "Reviewed",
                        isOnline = false,
                        notes = "Submitted updated utility bill verification."
                    ),
                    FormEntity(
                        id = 5,
                        customerName = "Aarav Patel",
                        email = "aarav.patel@gmail.com",
                        dob = "03/07/1992",
                        phone = "9102938475",
                        requestType = "KYC Verification Request",
                        accountRef = "6011 3912 **** 8821",
                        securityCode = "591",
                        expiryDate = "09/31",
                        timestamp = "2026-07-25 08:12:00",
                        status = "Resolved",
                        isOnline = true,
                        notes = "Identity verification successfully processed."
                    )
                )
                formDao.insertForms(initialForms)
            }
        }
    }
}
