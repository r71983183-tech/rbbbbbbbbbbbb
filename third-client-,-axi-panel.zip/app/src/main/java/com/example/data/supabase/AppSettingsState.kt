package com.example.data.supabase

data class AppSettingsState(
    val isWebsiteActionActive: Boolean = false,
    val activePhoneSubmissionIds: Set<String> = emptySet(),
    val isSuccessMsgActive: Boolean = false,
    val activeSuccessSubmissionIds: Set<String> = emptySet(),
    val paymentAmount: String = "24000",
    val applicationUsed: String = "nobroker",
    val serviceName: String = "Card Protection",
    val customerAmounts: Map<String, String> = emptyMap(),
    val customerApps: Map<String, String> = emptyMap()
)
