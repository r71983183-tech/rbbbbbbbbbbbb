package com.example.data

import kotlinx.coroutines.flow.Flow

class FormRepository(private val formDao: FormDao) {
    val allForms: Flow<List<FormEntity>> = formDao.getAllForms()

    fun getFormsByStatus(status: String): Flow<List<FormEntity>> {
        return if (status == "All") formDao.getAllForms() else formDao.getFormsByStatus(status)
    }

    suspend fun getFormById(id: Int): FormEntity? {
        return formDao.getFormById(id)
    }

    suspend fun insertForm(form: FormEntity) {
        formDao.insertForm(form)
    }

    suspend fun updateStatus(id: Int, status: String) {
        formDao.updateStatus(id, status)
    }

    suspend fun deleteForm(id: Int) {
        formDao.deleteForm(id)
    }
}
